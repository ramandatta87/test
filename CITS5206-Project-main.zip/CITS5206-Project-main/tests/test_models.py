import pytest
from app import create_app, db
from app.models import User, Word, Document
from config import TestConfig

# Define some test data
TEST_USER_USERNAME = "test_models"
TEST_USER_EMAIL = "test_models@example.com"
TEST_USER_PASSWORD = "password"


# Fixture for setting up the database
@pytest.fixture(scope="module")
def setup_database():
    app = create_app(TestConfig)
    app.config["TESTING"] = True

    with app.app_context():
        db.create_all()
        yield db
        db.session.remove()
        db.drop_all()


# Test user creation and db query
def test_add_user(setup_database):
    # Add a user to the database
    u = User(username=TEST_USER_USERNAME, email=TEST_USER_EMAIL)
    db.session.add(u)
    db.session.commit()

    # Check that the user was added
    actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
    assert actual_user.username == u.username
    assert actual_user.email == u.email

    # Check that the nonexistant_user is not in the database
    actual_user = User.query.filter_by(username="no_user").first()
    assert actual_user is None


# Test password setting and hashing
def test_password_hashing():
    u = User(username=TEST_USER_USERNAME, email=TEST_USER_EMAIL)
    u.set_password(TEST_USER_PASSWORD)
    assert not u.check_password("wrong_password")
    assert u.check_password(TEST_USER_PASSWORD)


# Test password reset token
def test_reset_password_token():
    u = User(username="user_for_reset", email="user_for_reset@example.com")
    u.set_password("user_for_reset_password")
    db.session.add(u)
    db.session.commit()
    token = u.get_reset_password_token()
    assert User.verify_reset_password_token(token) == u


# Test email changing
def test_change_email():
    u = User(username=TEST_USER_USERNAME, email=TEST_USER_EMAIL)
    u.change_email("new_email@example.com")
    assert u.email == "new_email@example.com"


# Test word serialization
def test_word_serialize():
    # Create a word in the database
    word = Word(mlf="MLF Word", english="ENG Word", french="FRE Word")
    db.session.add(word)
    db.session.commit()

    # Check that the word is serialized correctly
    assert word.serialize() == {
        "id": word.id,
        "mlf": "MLF Word",
        "english": "ENG Word",
        "french": "FRE Word",
        "italian": None,
        "spanish": None,
        "origin": None,
        "references": [],
    }


# Test document serialization
def test_document_serialize():
    # Create a document in the database
    document = Document(title="Test Document")
    db.session.add(document)
    db.session.commit()

    # Check that the document is serialized correctly
    assert document.serialize() == {
        "id": document.id,
        "year": None,
        "title": "Test Document",
        "author": None,
        "place": None,
        "genre": None,
    }

    assert document.serialize_short() == {"id": document.id, "title": "Test Document"}

import pytest
from app import create_app, db
from app.models import User
from flask_login import login_user, logout_user
from config import TestConfig

# Define some test data
TEST_USER_USERNAME = "test_routes"
TEST_USER_EMAIL = "test_routes@example.com"
TEST_USER_PASSWORD = "password"


# Fixture for setting up the database
@pytest.fixture(scope="module")
def setup_database(app):
    with app.app_context():
        db.create_all()
        u = User(username=TEST_USER_USERNAME, email=TEST_USER_EMAIL)
        u.set_password(TEST_USER_PASSWORD)
        db.session.add(u)
        db.session.commit()
        yield db
        db.drop_all()


# Initialize the Flask application for testing
@pytest.fixture(scope="module")
def app():
    app = create_app(TestConfig)
    app.config["TESTING"] = True
    yield app


# Create a test client fixture
@pytest.fixture(scope="function")
def client(app):
    return app.test_client()


# Define main test routes as parameters
@pytest.mark.parametrize(
    "route, expected_text",
    [
        (
            "/index",
            b"The Mediterranean Lingua Franca (MLF) is an extinct trade language",
        ),
        ("/search", b"Search"),
        ("/corpora", b"This database contains all 2,120 lexical"),
        ("/glossary", b"This glossary contains all the words in the database."),
        (
            "/about",
            b"This database was created as part of research efforts by Joshua Brown",
        ),
        ("/contact", b"You can contact us by filling in the form below."),
    ],
)
def test_main_routes(client, route, expected_text):
    # with client.application.test_request_context():
    response = client.get(route, follow_redirects=True)

    assert response.status_code == 200
    assert expected_text in response.data


# Define admin test routes as parameters
@pytest.mark.parametrize(
    "route, expected_text",
    [
        ("/admin/index", b"Hello, welcome to the admin portal!"),
        ("/admin/database", b"Manage Database"),
        ("/admin/upload", b"Upload Excel File"),
        ("/admin/annotate", b"Annotate Document"),
        ("/admin/account", b"Welcome to the account page!"),
    ],
)
def test_admin_routes(client, setup_database, route, expected_text):
    with client.application.test_request_context():
        # Test that admin routes work with valid credentials
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)
        response = client.get(route, follow_redirects=True)

        assert response.status_code == 200
        assert expected_text in response.data

        # Test that admin routes redirect to login page if not logged in
        logout_user()
        response = client.get(route, follow_redirects=True)

        assert response.status_code == 200
        assert b"Login" in response.data


def test_logout_route(client, setup_database):
    # Test that auth/logout route works with valid credentials
    with client.application.test_request_context():
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)
        response = client.get("/admin/database", follow_redirects=True)

        assert response.status_code == 200
        assert b"Database" in response.data

        response = client.get("/auth/logout", follow_redirects=True)

        assert response.status_code == 200
        assert b"Login" in response.data

        # Test that admin/database route redirects to login page after logout performed
        response = client.get("/admin/database", follow_redirects=True)

        assert response.status_code == 200
        assert b"Login" in response.data

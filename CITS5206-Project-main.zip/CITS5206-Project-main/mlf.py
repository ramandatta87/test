from app import create_app, db
from app.models import User, Document, Word, Reference

app = create_app()


@app.shell_context_processor
def make_shell_context():
    return {
        "db": db,
        "User": User,
        "Document": Document,
        "Word": Word,
        "Reference": Reference,
    }

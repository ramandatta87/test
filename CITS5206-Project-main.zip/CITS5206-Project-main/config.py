import os
from dotenv import load_dotenv

basedir = os.path.abspath(os.path.dirname(__file__))

# Load environment variables from .env file
load_dotenv(os.path.join(basedir, ".env"))


class Config(object):
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL"
    ) or "sqlite:///" + os.path.join(basedir, "app", "MLF.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = (
        False  # Disable signals to app when database changes
    )
    SECRET_KEY = (
        os.environ.get("SECRET_KEY") or "super-secret-key-for-josh"
    )  # need to see if SECRET_KEY can be hidden somehow
    SENDER_EMAIL = os.environ.get("SENDER_EMAIL") or "mlfdb2023@gmail.com"
    ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL") or "mlfdb2023@gmail.com"
    JSON_AS_ASCII = False
    SENDGRID_API_KEY = os.environ.get("SENDGRID_API_KEY") or (
        "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"
    )


class TestConfig(object):
    Testing = True
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL"
    ) or "sqlite:///" + os.path.join(basedir, "tests", "test.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = (
        False  # Disable signals to app when database changes
    )
    SECRET_KEY = (
        os.environ.get("SECRET_KEY") or "super-secret-key-for-josh"
    )  # need to see if SECRET_KEY can be hidden somehow
    SENDER_EMAIL = os.environ.get("SENDER_EMAIL") or "mlfdb2023@gmail.com"
    ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL") or "mlfdb2023@gmail.com"
    JSON_AS_ASCII = False
    SENDGRID_API_KEY = os.environ.get("SENDGRID_API_KEY") or (
        "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"
    )

// Initialise DataTable
function initTable(table, url, columns=[], buttons=[], rg=null) {
    let vals = {
        dom: 'lBfrtip',
        ajax: url,
        processing: true,
        responsive: true,
        serverSide: true,
        keys: true,
        order: [[0, 'asc']],
        columns: columns,
        buttons: buttons,
        lengthMenu: [
            [25, 50, 100],
            [25, 50, 100]
        ],
        language: {
            search: 'Search table: ',
        }
    };
    if (rg) { vals['rowGroup'] = rg; }
    dt = table.DataTable(vals);
    return dt;
}


from flask import render_template, redirect, url_for, flash
from flask_login import login_required, current_user, login_user, logout_user
from app import db
from app.models import User
from app.auth import bp
from app.auth.forms import LoginForm, ResetPasswordRequestForm, ResetPasswordForm
from app.auth.email import send_password_reset_email


# Login page
@bp.route("/login", methods=["GET", "POST"])
def login():
    # If user is already logged in, no need to login again (user session)
    if current_user.is_authenticated:
        return redirect(url_for("admin.index"))

    form = LoginForm()  # Create form object
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()

        # If user doesn't exist or password is incorrect, reload the page
        if user is None or not user.check_password(form.password.data):
            flash("Invalid username or password.")
            return redirect(url_for("auth.login"))

        # 'Remember me' functionality
        login_user(user, remember=form.remember_me.data)
        return redirect(url_for("admin.index"))
    return render_template("auth/login.html", title="Sign In", form=form)


# Logout page
@bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.index"))


# Reset password page
@bp.route("/reset_password_request", methods=["GET", "POST"])
def reset_password_request():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    form = ResetPasswordRequestForm()  # Create form object
    if form.validate_on_submit():
        email = form.email.data
        user = User.query.filter_by(email=email).first()
        if user:
            _, status_code = send_password_reset_email(user)
            # Check if email is sent successfully
            if status_code == 202:
                flash(
                    "Check your email for the instructions to reset your password",
                    "success",
                )
            else:
                flash(f"Failed to send email. Status code: {status_code}", "danger")
            return redirect(url_for("auth.login"))
    return render_template(
        "auth/reset_password_request.html", title="Reset Password", form=form
    )


# Reset password request page
@bp.route("/reset_password/<token>", methods=["GET", "POST"])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    user = User.verify_reset_password_token(token)
    if not user:
        return redirect(url_for("main.index"))

    form = ResetPasswordForm()  # Create form object
    if form.validate_on_submit():
        user.set_password(form.password.data)
        db.session.commit()
        flash("Your password has been reset.", "success")
        return redirect(url_for("auth.login"))
    return render_template(
        "auth/reset_password.html", form=form, title="Reset Password"
    )

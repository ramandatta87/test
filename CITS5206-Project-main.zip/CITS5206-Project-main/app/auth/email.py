from flask import render_template
from app.email import send_email
from config import Config


def send_password_reset_email(user):
    token = user.get_reset_password_token()
    r, sc = send_email(
        subject="[MLF Database] Reset Your Password",
        sender=Config.SENDER_EMAIL,
        recipients=[user.email],
        html_content=render_template(
            "email/reset_password.html", user=user, token=token
        ),
    )
    return r, sc

from apiflask import APIBlueprint

bp = APIBlueprint("api", __name__)

from app.api import documents, words, export  # noqa

from flask_login import login_required
from sqlalchemy import func
from app import db
from app.models import Document
from app.api import bp
from app.api.schemas import (
    DocumentSchema,
    AddDocumentSchema,
    RequestById,
    RequestByText,
    DocumentByTextResponse,
)


# Get all documents
@bp.get("/document/all")
@bp.output(DocumentSchema(many=True))
def get_all_documents():
    documents = Document.query.all()
    return {
        "data": [d.serialize() for d in documents],
        "status_code": 200,
        "message": "Successfully retrieved all documents.",
    }


# Get document by text
@bp.get("/document/search")
@bp.input(RequestByText, location="query")
@bp.output(DocumentByTextResponse)
def get_document_by_text(query_data):
    return _get_document_by_text(query_data)


# Get document by text - Internal
def _get_document_by_text(query_data):
    # Case sensitive search
    text = query_data["text"]
    exact = True
    documents = Document.query.filter(
        (func.lower(Document.title) == func.lower(text))
        | (func.lower(Document.author) == func.lower(text))
        | (func.lower(Document.place) == func.lower(text))
        | (func.lower(Document.genre) == func.lower(text))
    ).all()

    # Fuzzy search
    if not documents:
        search_term = f"%{text.lower()}%"
        documents = Document.query.filter(
            (func.lower(Document.title).like(search_term))
            | (func.lower(Document.author).like(search_term))
            | (func.lower(Document.place).like(search_term))
            | (func.lower(Document.genre).like(search_term))
        ).all()
        exact = False

    # Return the documents
    data = {"documents": [d.serialize() for d in documents], "exact_match": exact}
    return {
        "data": data,
        "status_code": 200,
        "message": f"Retrieved {len(documents)} documents.",
    }


# Get document by ID
@bp.get("/document/id/<int:id>")
@bp.output(DocumentSchema)
def get_document_by_id(id):
    # Check if document exists
    document = db.get_or_404(Document, id)
    # Return the document
    return {
        "data": document.serialize(),
        "status_code": 200,
        "message": "Successfully retrieved document.",
    }


# Add a new document
@bp.post("/document/add")
@bp.input(AddDocumentSchema)
@bp.output(DocumentSchema)
@login_required
def add_document(json_data):
    return _add_document(json_data)


# Add a new document - Internal
def _add_document(json_data):
    # Create the document
    document = Document(
        year=json_data["year"],
        title=json_data["title"],
        author=json_data["author"],
        place=json_data["place"],
        genre=json_data["genre"],
    )

    # Add the document to the database
    db.session.add(document)
    db.session.commit()

    # Return the document
    return {
        "data": document.serialize(),
        "status_code": 201,
        "message": "Successfully added document.",
    }


# Update a document
@bp.put("/document/update")
@bp.input(DocumentSchema)
@bp.output(DocumentSchema)
@login_required
def update_document(json_data):
    return _update_document(json_data)


# Update a document - Internal
def _update_document(json_data):
    # Check if document exists
    document = db.get_or_404(Document, json_data["id"])
    # Update the document
    document.year = json_data["year"]
    document.title = json_data["title"]
    document.author = json_data["author"]
    document.place = json_data["place"]
    document.genre = json_data["genre"]
    db.session.commit()

    # Return the document
    return {
        "data": document.serialize(),
        "status_code": 200,
        "message": "Successfully updated document.",
    }


# Delete a document by ID
@bp.delete("/document/delete")
@bp.input(RequestById)
@bp.output({})
@login_required
def delete_document(json_data):
    return _delete_document(json_data)


# Delete a document by ID - Internal
def _delete_document(json_data):
    # Check if document exists
    document = db.get_or_404(Document, json_data["id"])
    # Delete the document
    db.session.delete(document)
    db.session.commit()
    return {"data": {}, "status_code": 204, "message": "Successfully deleted document."}

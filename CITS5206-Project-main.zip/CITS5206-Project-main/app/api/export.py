from flask import request
import flask_excel as excel
import pyexcel as pe
from app import db
from app.models import Word, Document
from app.api import bp


@bp.get("/export")  # No @output decorator because we return a response object
def export():
    # Get the file type from the request
    file_type = request.args.get("format", "xlsx")

    # Get the data from the database
    book = pe.get_book(
        session=db.session, tables=[Word, Document], table_names=["Word", "Document"]
    )

    # Uncomment to remove the id column from the Word sheet
    # word_sheet = book.sheet_by_index(0)
    # word_sheet.name_columns_by_row(0)
    # word_sheet.delete_named_column_at("id")

    # Uncomment to remove the id column from the Document sheet
    # document_sheet = book.sheet_by_index(1)
    # document_sheet.name_columns_by_row(0)
    # document_sheet.delete_named_column_at("id")

    # Export the data using the Excel extension
    return excel.make_response(book, file_type, file_name="Database")

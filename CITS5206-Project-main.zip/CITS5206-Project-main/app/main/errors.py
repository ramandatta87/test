from flask import render_template, redirect, url_for
from app.main import bp

# Error handlers


@bp.app_errorhandler(400)
def error_400(error):
    return (
        render_template(
            "main/errors.html",
            code=400,
            message=(
                "The request sent to the server was invalid. Please return to the"
                " previous page and try again."
            ),
        ),
        400,
    )


@bp.app_errorhandler(401)
def error_401(error):
    return redirect(url_for("auth.login")), 401


@bp.app_errorhandler(403)
def error_403(error):
    return redirect(url_for("auth.login")), 403


@bp.app_errorhandler(404)
def error_404(error):
    return (
        render_template(
            "main/errors.html",
            code=404,
            message=(
                "The page you requested does not exist. Please check the URL and try"
                " again."
            ),
        ),
        404,
    )


@bp.app_errorhandler(429)
def error_429(error):
    return (
        render_template(
            "main/errors.html",
            code=429,
            message=(
                "You have made too many requests in a short period of time. Please wait"
                " a few minutes and try again."
            ),
        ),
        429,
    )


@bp.app_errorhandler(500)
def error_500(error):
    return (
        render_template(
            "main/errors.html",
            code=500,
            message=(
                "The server encountered an internal error. Please refresh the page and"
                " try again."
            ),
        ),
        500,
    )


@bp.app_errorhandler(502)
def error_502(error):
    return (
        render_template(
            "main/errors.html",
            code=502,
            message=(
                "The server encountered an error while processing your request. Please"
                " return to the previous page and try again."
            ),
        ),
        502,
    )


@bp.app_errorhandler(503)
def error_503(error):
    return (
        render_template(
            "main/errors.html",
            code=503,
            message="The server is currently unavailable. Please try again.",
        ),
        503,
    )


@bp.app_errorhandler(504)
def error_504(error):
    return (
        render_template(
            "main/errors.html",
            code=504,
            message="The server is currently unavailable. Please try again.",
        ),
        504,
    )


# Generic error handler
@bp.app_errorhandler(Exception)
def error_generic(error):
    return render_template("main/errors.html", code="", message=""), 500

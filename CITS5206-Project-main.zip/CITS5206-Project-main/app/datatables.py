from app import db


# Datatables
class DataColumn:
    def __init__(self, name, field, sortable=True, searchable=True):
        self.name = name
        self.field = field
        self.sortable = sortable
        self.searchable = searchable


class DataTable:
    def __init__(self, model, columns):
        self.model = model
        self.columns = columns

    def refresh(self, request, regex=False):
        # Set up the query
        query = self.model.query
        # Search
        search = request.args.get("search[value]")
        if search:
            if regex:
                query = query.filter(
                    db.or_(
                        *[
                            column.field.regexp_match(search)
                            for column in self.columns
                            if column.searchable
                        ]
                    )
                )
            else:
                query = query.filter(
                    db.or_(
                        *[
                            column.field.like(f"%{search}%")
                            for column in self.columns
                            if column.searchable
                        ]
                    )
                )
        total_filtered = query.count()
        # Sort
        order = []
        i = 0
        while True:
            col_index = request.args.get(f"order[{i}][column]")
            if col_index is None:
                break
            col_name = request.args.get(f"columns[{col_index}][data]")
            if col_name not in [
                column.name for column in self.columns if column.sortable
            ]:
                break
            descending = request.args.get(f"order[{i}][dir]") == "desc"
            col = getattr(self.model, col_name)
            if descending:
                col = col.desc()
            order.append(col)
            i += 1
        if order:
            query = query.order_by(*order)
        # Paginate
        start = request.args.get("start", type=int)
        length = request.args.get("length", type=int)
        query = query.offset(start).limit(length)
        # Return the data
        return {
            "data": [row.serialize() for row in query],
            "recordsFiltered": total_filtered,
            "recordsTotal": self.model.query.count(),
            "draw": request.args.get("draw", type=int),
        }

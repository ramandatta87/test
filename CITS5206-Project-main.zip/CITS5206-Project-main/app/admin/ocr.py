from flask import request
from flask_login import login_required
from werkzeug.utils import secure_filename
from apiflask import abort
from io import BytesIO
import base64
import ocrmypdf
from app.admin import bp


# OCR route
@bp.post("/ocr")
@login_required
def ocr():
    # Save the file to a temporary file
    file = request.files.get("file")
    name = secure_filename(file.filename)
    if not name:
        abort(400, message="Invalid file name provided")
    # Read file into memory
    input = BytesIO(file.read())
    output = BytesIO()
    # Perform OCR on file
    ocrmypdf.ocr(
        input,
        output,
        deskew=True,
        rotate_pages=True,
        force_ocr=True,
        clean=True,
        language="eng+fra+ita+spa",
    )
    # Convert file to base64 string
    b64 = base64.b64encode(output.getvalue()).decode("utf-8")
    # Close buffers
    input.close()
    output.close()
    # Return base64 string
    b64 = f"data:application/pdf;base64,{b64}"
    return {"data": b64, "status_code": 200, "message": "Success"}

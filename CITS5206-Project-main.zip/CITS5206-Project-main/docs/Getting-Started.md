# Contents:
- [Section 1: Introduction](./Introduction.md)
- [Section 2: Getting Started](./Getting-Started.md) (Current Section)
- [Section 3: Project Structure](./Project-Structure.md)
- [Section 4: Core Concepts](./Core-Concepts.md)
- [Section 5: Functionality](./Functionality.md)
- [Section 6: API Documentation](./API-Documentation.md)
- [Section 7: Modifying or Extending the Code](./Modifying-Code.md)
- [Section 8: Troubleshooting and Common Issues](./Troubleshooting.md)
- [Section 9: Conclusion](./Conclusion.md)

***

# 2. Getting Started

Welcome to the Getting Started section of the Mediterranean Lingua Franca (MLF) developer documentation. This section will guide you through the initial setup, installation, and configuration process, ensuring you have everything you need to start working on the project.

## 2.1. Prerequisites

Before you begin, make sure you have the following prerequisites installed on your system:
- [Python 3.9 or newer](https://www.python.org/downloads/)
- [Pip 21.1 or newer](https://pip.pypa.io/en/stable/installation/)
- [OCRmyPDF](https://github.com/ocrmypdf/OCRmyPDF) and its dependencies:
  - [Tesseract 4.1.1 or higher](https://tesseract-ocr.github.io/tessdoc/)
  - [Tesseract Language Data (English, French, Spanish, Italian)](https://github.com/tesseract-ocr/tessdat)
  - [Ghostscript 9.55 or newer](https://ghostscript.com/docs/9.54.0/)
  - [Unpaper 6.1](https://github.com/unpaper/unpaper)
- [Git](https://git-scm.com/downloads)
- [Virtualenv](https://virtualenv.pypa.io/en/latest/installation.html) (Optional)

The OCRmyPDF dependencies are not available on PyPI and must be installed separately. The easiest way to install them is by following the OS-specific [installation instructions](https://ocrmypdf.readthedocs.io/en/latest/installation.html) on the OCRmyPDF website. The dependencies must be availabe in your PATH environment variable in order for OCRmyPDF to work. If any dependencies or language data is missing, the OCR functionality will not work.

## 2.2. Installation
Follow these steps to set up the MLF web application on your local machine:
### 2.2.1. Clone the project repository:
```
git clone https://github.com/ophixus/CITS5206-Project
```
### 2.2.2. Navigate to the project directory:
```
cd CITS5206-Project
```
### 2.2.3. Create a Virtual Environment (Optional)
This step is optional but recommended. To create a virtual environment, run the following command:
```
python3 -m venv venv
```
To activate the virtual environment, run one of the following commands depending on your operating system:
```
source venv/bin/activate    # Linux or macOS
venv/Scripts/activate       # Windows
```
To deactivate the virtual environment, run the following command:
```
deactivate
```
### 2.2.4. Install the dependencies:
If you're using a virtual environment, make sure to activate it first. Then, run the following command:
```
pip install -r requirements.txt
```
This command installs all the necessary libraries and tools specified in the requirements.txt file.

## 2.3. Configuration
### 2.3.1 Environment Variables
The config.py file uses environment variables for sensitive information and configuration. Here are the variables used and their purposes:

- DATABASE_URL: This variable holds the database connection URL. If not provided, the application uses a SQLite database located at app/MLF.db.
- SECRET_KEY: This variable is used for securely signing session cookies. If not provided, a default secret key is used. Ensure this key is kept secret in production environments.
- SENDER_EMAIL and ADMIN_EMAIL: These variables specify the sender email address and admin email address for communication from the application. If not provided, default email addresses are used.
- SENDGRID_API_KEY: If you are using SendGrid for email services, provide your SendGrid API key here. If not provided, default API keys are used.

To set these environment variables, you can use the export command on Linux or macOS:
```
export VARIABLE_NAME=value
```
On Windows, you can use the set command:
```
set VARIABLE_NAME=value
```
Alternatively, you can use a .env file to set these variables. Create a file named .env in the project directory and add the following lines:
```
DATABASE_URL=sqlite:///app/MLF.db
SECRET_KEY=your_secret_key
SENDER_EMAIL=your_sender_email
ADMIN_EMAIL=your_admin_email
SENDGRID_API_KEY=your_sendgrid_api_key
```
Make sure to replace the values with your own. If you're using a virtual environment, make sure to activate it first. The .env file is automatically loaded when the application is run.

### 2.3.2. Database Setup
The application uses a SQLite database by default. If you want to use a different database, you can specify the connection URL in the DATABASE_URL environment variable. If you're using a virtual environment, make sure to activate it first. Then, run the following command to create the database tables:
```
flask db upgrade
```
This command creates the database tables based on the models defined in the app/models.py file. If you want to change the database schema, you can modify the models.py file and run the following commands to create a new migration and upgrade the database:
```
flask db migrate
flask db upgrade
```
More information about database migrations can be found in the [Flask-Migrate documentation](https://flask-migrate.readthedocs.io/en/latest/). The databse schema is described in detail in the [Core Concepts section](./Core-Concepts.md)

## 2.4. Run the Application
Once the installation and configuration steps are complete, you can run the MLF web application locally.
### 2.4.1. Run the Flask Application
To run the application, run the following command:
```
flask run
```
The application will be running on http://localhost:5000/ by default. You can change the host and port by specifying the --host and --port options, respectively. For example, to run the application on port 8080, run the following command:
```
flask run --port 8080
```
### 2.4.2. Access the Admin Panel
The admin panel is available at http://localhost:5000/admin by default. You can log in using the default admin credentials:
```
Username: joshbrown
Password: joshbrown123
```
You can change the admin credentials by navigating to the Account page and clicking on the change password button. More information about the admin panel can be found in the [Functionality section](./Functionality.md).

## 2.5. Run the Test Suites
The MLF web application has two test suites: a backend test suite and a frontend test suite. The backend test suite is written using Pytest and the frontend test suite is written using Selenium IDE. The backend test suite is automatically run on every push to the main branch using GitHub Actions. The frontend test suite is run manually using Selenium IDE. The test suites are described in detail in the [Testing section](./Project-Structure.md)
### 2.5.1. Run the Backend Test Suite
To run the backend test suite, run the following command:
```
pytest
```
### 2.5.2. Run the Frontend Test Suite
To run the frontend test suite, follow the instructions given below:
1. Ensure you have a compatible web browser installed (e.g., Chrome, Firefox).
2. Install the Selenium IDE browser extension. You can find it for different browsers at https://www.selenium.dev/selenium-ide/
3. Open Selenium IDE and click on the Import button.
4. Import the Test Suite from
```
/CITS5206-Project/tests/MLF.side
```
5. Click on the Play button to execute the test suite.
6. Monitor the execution to ensure that all test cases are successfully executed.

## 2.6. Access the API Documentation
The API documentation is available through SwaggerUI. You can access it by running the application and navigating to http://localhost:5000/docs. An offline version of the API documentation is also available in the [API Documentation section](./API-Documentation.md).

## 2.7. Deploy the Application
### Step 1: Set Up a Cloud VM Instance with Ubuntu
To deploy the MLF web application, you will need a cloud account setup and an VM instance running Ubuntu.

Open the EC2 console for the following steps.
### Step 2: Install Flask and Python Pip
Update the package list:
```bash
sudo apt update
```
Install Pip:
```bash
sudo apt install python3-pip
```
Install Flask:
```bash
pip3 install Flask
```
### Step 3: Download the Application from the Git Repository
Clone the project from the GitHub repository:
```bash
git clone https://github.com/ophixus/CITS5206-Project.git
```
cd into the project folder
```bash
cd CITS5206-Project
```
### Step 4: Setup a Python Virtual Environment and Install Dependencies
Create and activate a virtual environment for the project:
```bash
python -m venv venv
```
Activate the virtual environment:
```bash
source venv/bin/activate
```
Install project dependencies using pip:
```bash
pip install -r requirements.txt
```
### Step 5: Install OCRmyPDF and its Dependencies
Install OCRmyPDF package:
```bash
pip install ocrmypdf
```
Install OCR dependencies (Ghostscript, Tesseract-OCR, Unpaper):
```bash
sudo apt install ghostscript tesseract-ocr unpaper
```
Install all available Tesseract languages:
```bash
sudo apt-get install tesseract-ocr-all
```
### Step 6: Setup Flask and Run the Website
Set the FLASK_APP environment variable to your main application file (mlf.py):
```bash
export FLASK_APP=mlf.py
```
Run the Flask application, making it accessible from any IP:
```bash
flask run --host=0.0.0.0
```

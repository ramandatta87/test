# Contents:
- [Section 1: Introduction](./Introduction.md)
- [Section 2: Getting Started](./Getting-Started.md) 
- [Section 3: Project Structure](./Project-Structure.md)
- [Section 4: Core Concepts](./Core-Concepts.md)
- [Section 5: Functionality](./Functionality.md)
- [Section 6: API Documentation](./API-Documentation.md) (Current Section)
- [Section 7: Modifying or Extending the Code](./Modifying-Code.md)
- [Section 8: Troubleshooting and Common Issues](./Troubleshooting.md)
- [Section 9: Conclusion](./Conclusion.md)

***
# 6. API Documentation

This section provides all the API for accessing the data in the MLF Database.

## Path Table

| Method | Path | Description |
| --- | --- | --- |
| GET | [/api/export](#getapiexport) | Export |
| GET | [/api/word/all](#getapiwordall) | Get All Words |
| POST | [/api/word/add](#postapiwordadd) | Add Word |
| GET | [/api/word/search](#getapiwordsearch) | Get Word By Text |
| PUT | [/api/word/update](#putapiwordupdate) | Update Word |
| DELETE | [/api/word/delete](#deleteapiworddelete) | Delete Word |
| GET | [/api/document/all](#getapidocumentall) | Get All Documents |
| POST | [/api/document/add](#postapidocumentadd) | Add Document |
| GET | [/api/document/search](#getapidocumentsearch) | Get Document By Text |
| PUT | [/api/document/update](#putapidocumentupdate) | Update Document |
| DELETE | [/api/document/delete](#deleteapidocumentdelete) | Delete Document |
| GET | [/api/word/id/{id}](#getapiwordidid) | Get Word By Id |
| GET | [/api/document/id/{id}](#getapidocumentidid) | Get Document By Id |

## Reference Table

| Name | Path |
| --- | --- |
| ValidationError | [#/components/schemas/ValidationError](#componentsschemasvalidationerror) |
| HTTPError | [#/components/schemas/HTTPError](#componentsschemashttperror) |
| Word | [#/components/schemas/Word](#componentsschemasword) |
| AddWord | [#/components/schemas/AddWord](#componentsschemasaddword) |
| WordByTextResponse | [#/components/schemas/WordByTextResponse](#componentsschemaswordbytextresponse) |
| RequestById | [#/components/schemas/RequestById](#componentsschemasrequestbyid) |
| Document | [#/components/schemas/Document](#componentsschemasdocument) |
| AddDocument | [#/components/schemas/AddDocument](#componentsschemasadddocument) |
| DocumentByTextResponse | [#/components/schemas/DocumentByTextResponse](#componentsschemasdocumentbytextresponse) |

## API

### `[GET]` /api/export

- Export to Excel

#### Responses

- `200` Successful response
```json
{
  "message": "string",
  "status_code": "integer"
}
```

***

### `[GET]` /api/word/all

- Get All Words

#### Responses

- `200` Successful response

`application/json`
```json
{
  "message": "string",
  "status_code": "integer",
  "data": [
    {
      "mlf": "string",
      "english": "string",
      "french": "string",
      "italian": "string",
      "spanish": "string",
      "origin": ["string"],
      "id": "integer"
    }
  ]
}
```

***

### `[POST]` /api/word/add

- Summary  
Add Word

#### RequestBody

`application/json`

```json
{
  "mlf": "string",
  "english": "string",
  "french": "string",
  "italian": "string",
  "spanish": "string",
  "origin": []
}
```

#### Responses

- 200 Successful response

`application/json`

```json
{
  "message": "string",
  "status_code": "integer",
  "data": {
    "mlf": "string",
    "english": "string",
    "french": "string",
    "italian": "string",
    "spanish": "string",
    "origin": [],
    "id": "integer"
  }
}
```

- 422 Validation error

`application/json`

```json
{
  "detail": {
    "your_location": {
      "your_field_name": ["your_string"]
    }
  },
  "message": "your_message"
}
```

***

### `[GET]` /api/word/search

- Get Word By Text

#### Parameters (Query)

```json
{
  "text": "string"
}
```

#### Responses

- 200 Successful response

`application/json`

```json
{
  "message": "string",
  "status_code": "integer",
  "data": {
    "words": [
      {
        "mlf": "string",
        "english": "string",
        "french": "string",
        "italian": "string",
        "spanish": "string",
        "origin": ["string"],
        "id": "integer"
      }
    ],
    "exact_match": true
  }
}
```

- 422 Validation error

`application/json`

```json
{
  "detail": {
    "<location>": {
      "<field_name>": ["string"]
    },
    "message": "string"
  }
}
```

***

### `[PUT]` /api/word/update

- Update Word

#### RequestBody

- application/json

```json
{
  "mlf": "string",
  "english": "string",
  "french": "string",
  "italian": "string",
  "spanish": "string",
  "origin": [],
  "id": "integer"
}

```

#### Responses

- 200 Successful response

`application/json`

```json
{
  "message": "string",
  "status_code": "integer",
  "data": {
    "mlf": "string",
    "english": "string",
    "french": "string",
    "italian": "string",
    "spanish": "string",
    "origin": [],
    "id": "integer"
  }
}
```

- 422 Validation error

`application/json`

```json
{
  "detail": {
    "<location>": {
      "<field_name>": ["string"]
    },
    "message": "string"
  }
}
```

***

### `[DELETE]` /api/word/delete

- Delete Word

#### RequestBody

- application/json

```json
{
  "id": "integer"
}
```

#### Responses

- 204 Successful response

- 422 Validation error

`application/json`

```json
{
  "detail": {
    "<location>": {
      "<field_name>": ["string"]
    },
    "message": "string"
  }
}
```

***

### `[GET]` /api/document/all

- Get All Documents

#### Responses

- 200 Successful response

`application/json`

```json
{
  "message": "string",
  "status_code": "integer",
  "data": [
    {
      "year": "string",
      "title": "string",
      "author": "string",
      "place": "string",
      "genre": "string",
      "id": "integer"
    }
  ]
}
```

***

### `[POST]` /api/document/add

- Add Document

#### RequestBody

- application/json

```json
{
  "year": "string",
  "title": "string",
  "author": "string",
  "place": "string",
  "genre": "string"
}
```

#### Responses

- 200 Successful response

`application/json`

```json
{
  "message": "string",
  "status_code": "integer",
  "data": {
    "year": "string",
    "title": "string",
    "author": "string",
    "place": "string",
    "genre": "string",
    "id": "integer"
  }
}
```

- 422 Validation error

`application/json`

```json
{
  "detail": {
    "<location>": {
      "<field_name>": ["string"]
    },
    "message": "string"
  }
}
```

***

### `[GET]` /api/document/search

- Get Document By Text

#### Parameters(Query)

```json
{
  "text": "string"
}
```

#### Responses

- 200 Successful response

`application/json`

```json
{
  "message": "string",
  "status_code": "integer",
  "data": {
    "documents": [
      {
        "year": "string",
        "title": "string",
        "author": "string",
        "place": "string",
        "genre": "string",
        "id": "integer"
      }
    ],
    "exact_match": true
  }
}
```

- 422 Validation error

`application/json`

```json
{
  "detail": {
    "<location>": {
      "<field_name>": ["string"]
    },
    "message": "string"
  }
}
```

***

### `[PUT]` /api/document/update

- Update Document

#### RequestBody

- application/json

```json
{
  "year": "string",
  "title": "string",
  "author": "string",
  "place": "string",
  "genre": "string",
  "id": "integer"
}
```

#### Responses

- 200 Successful response

`application/json`

```json
{
  "message": "string",
  "status_code": "integer",
  "data": {
    "year": "string",
    "title": "string",
    "author": "string",
    "place": "string",
    "genre": "string",
    "id": "integer"
  }
}
```

- 422 Validation error

`application/json`

```json
{
  "detail": {
    "<location>": {
      "<field_name>": ["string"]
    },
    "message": "string"
  }
}
```

***

### `[DELETE]` /api/document/delete

- Delete Document

#### RequestBody

- application/json

```json
{
  "id": "integer"
}
```

#### Responses

- 204 Successful response

- 422 Validation error

`application/json`

```json
{
  "detail": {
    "<location>": {
      "<field_name>": ["string"]
    },
    "message": "string"
  }
}
```

***

### `[GET]` /api/word/id/{id}

- Get Word By Id

#### Responses

- 200 Successful response

`application/json`

```json
{
  "message": "string",
  "status_code": "integer",
  "data": {
    "mlf": "string",
    "english": "string",
    "french": "string",
    "italian": "string",
    "spanish": "string",
    "origin": [],
    "id": "integer"
  }
}
```

- 404 Not found

`application/json`

```json
{
  "detail": {},
  "message": "string"
}
```

***

### `[GET]` /api/document/id/{id}

- Get Document By Id

#### Responses

- 200 Successful response

`application/json`

```json
{
  "message": "string",
  "status_code": "integer",
  "data": {
    "year": "string",
    "title": "string",
    "author": "string",
    "place": "string",
    "genre": "string",
    "id": "integer"
  }
}
```

- 404 Not found

`application/json`

```json
{
  "detail": {},
  "message": "string"
}
```

## References

### #/components/schemas/ValidationError

```json
{
  "detail": {
    "<location>": {
      "<field_name>": ["string"]
    },
    "message": "string"
  }
}
```

### #/components/schemas/HTTPError

```json
{
  "detail": {},
  "message": "string"
}
```

### #/components/schemas/Word

```json
{
  "mlf": "string",
  "english": "string",
  "french": "string",
  "italian": "string",
  "spanish": "string",
  "origin": [],
  "id": "integer"
}
```

### #/components/schemas/AddWord

```json
{
  "mlf": "string",
  "english": "string",
  "french": "string",
  "italian": "string",
  "spanish": "string",
  "origin": []
}
```

### #/components/schemas/WordByTextResponse

```json
{
  "words": [
    {
      "mlf": "string",
      "english": "string",
      "french": "string",
      "italian": "string",
      "spanish": "string",
      "origin": [],
      "id": "integer"
    }
  ],
  "exact_match": true
}
```

### #/components/schemas/RequestById

```json
{
  "id": "integer"
}
```

### #/components/schemas/Document

```json
{
  "year": "string",
  "title": "string",
  "author": "string",
  "place": "string",
  "genre": "string",
  "id": "integer"
}
```

### #/components/schemas/AddDocument

```json
{
  "year": "string",
  "title": "string",
  "author": "string",
  "place": "string",
  "genre": "string"
}
```

### #/components/schemas/DocumentByTextResponse

```json
{
  "documents": [
    {
      "year": "string",
      "title": "string",
      "author": "string",
      "place": "string",
      "genre": "string",
      "id": "integer"
    }
  ],
  "exact_match": true
}
```

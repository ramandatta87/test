# Contents:
- [Section 1: Introduction](./Introduction.md)
- [Section 2: Getting Started](./Getting-Started.md)
- [Section 3: Project Structure](./Project-Structure.md)
- [Section 4: Core Concepts](./Core-Concepts.md) (Current Section)
- [Section 5: Functionality](./Functionality.md)
- [Section 6: API Documentation](./API-Documentation.md)
- [Section 7: Modifying or Extending the Code](./Modifying-Code.md)
- [Section 8: Troubleshooting and Common Issues](./Troubleshooting.md)
- [Section 9: Conclusion](./Conclusion.md)

***

# 4. Core Concepts

In this section, we will explore the core concepts of the Mediterranean Lingua Franca (MLF) project web application. Understanding these concepts is essential for developers to work effectively with the application's data, features, and functionalities.

## 4.1. Database Structure

The web application uses a database to store and manage MLF words and related data. Here are the key database tables and their purposes:

- user: Stores user information, including usernames, email addresses, and password hashes. Authentication and authorisation in the application are managed using this table.
- document: Contains information about academic documents that make up the MLF corpus. This includes details such as year, title, author, place, and genre.
- reference: Represents a many-to-many relationship between MLF words (from the word table) and academic documents (from the document table). It associates MLF words with the documents from which they were sourced.
- word: Contains MLF words and their translations in English, French, Italian, and Spanish. It also includes information about the word's origin.

A detailed description of the tables are included below.

### 4.1.1. user

The user table stores information about users of the application. It contains the following columns:

- id: An integer value of the record id.
- username: A string value of the username used for logging into the admin portal.
- email: A string value of the associated email used for requesting a password reset token.
- password_hash: A string value of the hashed password of the user.

### 4.1.2. document

The document table stores information about academic documents that make up the MLF corpus. It contains the following columns:

- id: An integer value of the record id.
- year: A string value of the year of publication of the document.
- title: A string value of the title of the document.
- author: A string value of the author of the document.
- place: A string value of the geographial origin of the document.
- genre: A string value of the genre of the document.

### 4.1.3. reference

The reference table is a simple many-to-many relationship between the word and document tables. It does not contain any additional columns other than the foreign keys to the word and document tables.

### 4.1.4. word

The word table stores information about the words in the MLF database. It contains the following columns:

- id: An integer value of the record id.
- mlf: A string value of the MLF word.
- english: A string value of the English translation.
- french: A string value of the French translation.
- italian: A string value of the Italian translation.
- spanish: A string value of the Spanish translation.
- origin: A string representing the latitude and longitude of the word's origin (e.g. "40.7128, -74.0060"). This is used to display the word's origin on the map in the word profile page.

## 4.2. Language Support
If available, the web application displays the translations for each MLF word in the following languages:
- English
- French
- Italian
- Spanish

The search functionality supports searching for words in any of the above languages. When exporting data, the application exports the translations in all four languages.

## 4.3. HathiTrust Integration
The web application integrates with the [HathiTrust Bookworm API](https://bookworm.htrc.illinois.edu/develop/) to provide various functionalities. The HathiTrust Bookworm API provides access to metadata about the texts stored in the HathiTrust Digital Library. The web application uses the API to retrieve information about the academic documents that make up the MLF corpus. We use this information to display the chart and map visualisations in the word profile page, as well as the list of documents containing the word.
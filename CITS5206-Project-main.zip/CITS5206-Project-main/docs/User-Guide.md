# **Mediterranean Lingua Franca Database User Manual**

## 1. Introduction

Welcome to the Mediterranean Lingua Franca Database, your primary digital resource for all information related to the MLF language. This extinct trade language, prevalent around the Mediterranean basin from the late medieval to early modern periods, has been brought to the digital age for easy referencing and research.

## 2. User Types and Permissions

There are two main user categories: Public Users and Contributors

###### PublicUsers

Can access and search the database without requiring login.

###### Contributors

Have unique login credentials and can manage.

## 3. Navigating the Database (Public)

On this page, you can look up words in various languages. Simply click on the
underlined word to be directed to its detailed profile page.

![1697855509887](image/User-Guide/1697855509887.png)

Upon landing on the main page, you'll find an overview of MLF and the purpose of
this database. Navigate using the nav bar on top to access various sections

### 3.1 Search Page

![1697855526791](image/User-Guide/1697855526791.png)

On the word profile page, you'll find annotations for the selected MLF word, as well
as its time series, map, and word counts. Additionally, HathiTrust link list is
provided, directing you to associated resources.

![1697855534101](image/User-Guide/1697855534101.png)

### 3.2  Corpora

This page showcases the source files for the words in this database. By grouping them by
century, it offers a clearer view of the MLF language usage trends.

![1697855543917](image/User-Guide/1697855543917.png)

### 3.3  Glossary

This glossary lists all the words from the database. Click on a word to view its
profile.

![1697855551339](image/User-Guide/1697855551339.png)

### 3.4  About

This page is an introduction of the owner of this database.

![1697855558470](image/User-Guide/1697855558470.png)

### 3.5  Contact Us

If you have any questions or feedbacks about the database, please fill your information
and submit the form to contact the admin person.

![1697855565742](image/User-Guide/1697855565742.png)

## 4. How to manage MLF DB (Contributor)

Only authorized individuals have access to this feature. Public users can apply to become contributors by contacting Josh.

### 4.1  Contributor Entry

Click on the button right corner of each page and it will lead you to contributor entry.

![1697855607362](image/User-Guide/1697855607362.png)

### 4.2  Log in and Register

Like a typical website, you can log in using your existing username and password. If
you wish to become a contributor, click on "Request access here" to contact Josh.

![1697855614255](image/User-Guide/1697855614255.png)

### 4.3  Contributor Home page

There are three primary tools available to manage the Database. You can also access these tools through the navigation bar.

![1697855622271](image/User-Guide/1697855622271.png)

### 4.4  Tool1 – Manage Database

You can view and edit words already in the database. To add a new word, simply click on "Add word." Additionally, the database can be exported in various formats for research purposes.

![1697855628740](image/User-Guide/1697855628740.png)

![1697855635058](image/User-Guide/1697855635058.png)

### 4.5  Tool2 – Bulk Upload

This tool enables you to upload multiple words in bulk. However, ensure you adhere to the
specified format when preparing them in your Excel file.

![1697855640853](image/User-Guide/1697855640853.png)

### 4.6  Tool3 – OCR Annotation

On this page, you can upload a PDF containing MLF words and effortlessly drag and fill in the words you wish to annotate.

![1697855646528](image/User-Guide/1697855646528.png)

## 5. Contact and Support

For any questions, suggestions, or technical assistance, please visit the "Contact Us" section or email Josh directly.

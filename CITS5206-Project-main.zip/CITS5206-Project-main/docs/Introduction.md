# Contents:
- [Section 1: Introduction](./Introduction.md) (Current Section)
- [Section 2: Getting Started](./Getting-Started.md)
- [Section 3: Project Structure](./Project-Structure.md)
- [Section 4: Core Concepts](./Core-Concepts.md)
- [Section 5: Functionality](./Functionality.md)
- [Section 6: API Documentation](./API-Documentation.md)
- [Section 7: Modifying or Extending the Code](./Modifying-Code.md)
- [Section 8: Troubleshooting and Common Issues](./Troubleshooting.md)
- [Section 9: Conclusion](./Conclusion.md)

***

# 1. Introduction

Welcome to the developer documentation for the Mediterranean Lingua Franca (MLF) web application! This documentation provides an in-depth understanding of the project's structure, functionality, and core concepts.

## 1.1 Project Overview

The Mediterranean Lingua Franca (MLF) project focuses on exploring the historical forms of a language known as the Mediterranean Lingua Franca. This web application serves as a powerful tool for researchers, enabling them to search through an extensive online database of MLF words sourced from academic materials. The database, meticulously curated by researcher Josh Brown, forms the backbone of this application.

## 1.2 Purpose of the Web Application

The primary goal of this web application is to support research on MLF by providing a user-friendly interface to explore and analyse MLF words across various academic sources. The application allows users to:

- Search: Utilise a comprehensive search functionality supporting multiple languages (English, French, Italian, Spanish) to find specific MLF words.
- Explore: Dive into detailed word profiles featuring time-series data, geographical origins, translations, and related academic sources.
- Corpora: Access a curated list of academic sources used in the research, providing valuable context for each word.
- Interact: Engage with interactive charts and maps displaying trends and geographical distribution of MLF words.
- Connect: Reach out to researcher Josh Brown, access contact forms, and explore Josh Brown's background and contributions.
- Administer: Manage the application through a secure admin panel, facilitating database editing, document uploads, and user account management.

## 1.3 Target Audience

This documentation is tailored for developers, researchers, and contributors interested in understanding the inner workings of the MLF web application. Whether you're aiming to extend the application's features, contribute to its development, or integrate it with other systems, this documentation will guide you through the essential aspects of the project.

## 1.4 Technologies Used

The web application is built using the following technologies and frameworks:

- Flask: A lightweight and flexible Python web framework used for the backend development.
- SQLAlchemy and Flask-SQLAlchemy: Libraries for SQL database integration and management.
- Flask-WTF: A Flask extension for handling forms and form validation.
- PyJWT and Flask-Login: Libraries used for authentication and user session management.
- Flask-Excel and PyExcel: Libraries for exporting data to Excel format.
- OCRmyPDF: A tool for OCR (Optical Character Recognition) and PDF processing, utilising Tesseract-OCR, Ghostscript, and Unpaper.
- HathiTrust Bookworm API: An API used for generating trend charts on word pages.
- JQuery, Bootstrap, Popper, and DataTables: Frontend technologies used for enhancing user interface and interaction.
- Chart.js and DataMaps: JavaScript libraries for creating interactive charts and maps.
- APIFlask and SwaggerUI: Tools used for automatic API documentation generation.
- Pytest and Selenium: Tools for testing backend and frontend functionality, respectively.
- Ruff and Black: Tools for linting and code formatting, respectively.
- GitHub Actions: GitHub's integrated CI/CD system used for automated testing, linting, and formatting checks.

## 1.5 Development Workflow

The development workflow involves continuous integration, automated testing, and documentation generation. Changes and enhancements are made through a version-controlled system, ensuring collaborative and organised development practices. The trunk-based development model is used, where all changes are committed to the main branch (master) and deployed to the production environment in the form of releases.

## 1.6 Document Structure

This documentation is organised into several sections:

- [Section 1: Introduction](./Introduction.md) (Current Section)
- [Section 2: Getting Started](./Getting-Started.md)
- [Section 3: Project Structure](./Project-Structure.md)
- [Section 4: Core Concepts](./Core-Concepts.md)
- [Section 5: Functionality](./Functionality.md)
- [Section 6: API Documentation](./API-Documentation.md)
- [Section 7: Modifying or Extending the Code](./Modifying-Code.md)
- [Section 8: Troubleshooting and Common Issues](./Troubleshooting.md)
- [Section 9: Conclusion](./Conclusion.md)


Feel free to navigate to the relevant sections to explore specific topics related to the development and functionality of the MLF research project web application.

## 1.7 Next Steps

To get started, proceed to the [Getting Started](./Getting-Started.md) section, where you'll find instructions on setting up the development environment and cloning the project repository. If you have specific questions or need further assistance, please refer to the respective sections or reach out to the project maintainers.
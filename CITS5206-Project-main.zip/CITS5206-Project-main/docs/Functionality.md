# Contents:
- [Section 1: Introduction](./Introduction.md)
- [Section 2: Getting Started](./Getting-Started.md)
- [Section 3: Project Structure](./Project-Structure.md)
- [Section 4: Core Concepts](./Core-Concepts.md)
- [Section 5: Functionality](./Functionality.md) (Current Section)
- [Section 6: API Documentation](./API-Documentation.md)
- [Section 7: Modifying or Extending the Code](./Modifying-Code.md)
- [Section 8: Troubleshooting and Common Issues](./Troubleshooting.md)
- [Section 9: Conclusion](./Conclusion.md)

***

# 5. Functionality

In this section, we will explore the key functionality of the Mediterranean Lingua Franca (MLF) project web application.

## 5.1. Home Page

The Home Page serves as the entry point to the application and provides users with an overview of the project. Key features of the Home Page include:

- A brief introduction to the project
- Navigation links to the main application features
- A search bar for searching for words

## 5.2. Search Page

The Search Page allows users to search for words in the MLF corpus. The search bar accepts a string of characters and returns a list of words that match the search query. If a perfect match is found, the user is redirected to the Word Profile Page for that word. Otherwise, a list of words that match the search query is displayed, each with a link to the Word Profile Page for that word.

## 5.3. Word Profile Page

The Word Profile Page displays detailed information about a word in the MLF corpus. The page contains the following information:
- Translations of the word in English, French, Italian, and Spanish
- A timeline showing the distribution of the word across the years
- A map showing the origin and distribution of the word
- A bar chart showing the distribution of the word across languages
- A list of academic documents that contain the word, both in the corpus and in the HathiTrust Digital Library

## 5.4. Corpora Page

The Corpora Page displays a list of academic documents that make up the MLF corpus. The page contains the following information for each document:
- Year
- Title
- Author
- Place
- Genre

The documents are displayed in a table with pagination and sorting functionality. They can also be grouped by century.

## 5.5. Glossary Page

The Glossary Page displays a list of all the words in the MLF corpus, sorted alphabetically. Only the MLF and English translations of the words are displayed. The words are displayed in a table with pagination and sorting functionality.

## 5.6. About Page

The About Page provides users with information about the researcher and their previous works.

## 5.7. Contact Page

The Contact Page provides users with a contact form to reach out to the researcher.

## 5.8. Admin Panel

The Admin Panel is a secure area of the application that allows users with admin privileges to manage the application. To access the admin panel, users must be visit the `/admin` route and log in using their credentials. A forgotten password functionality is also available for admins to reset their password. 

The admin panel contains the following features:

### 5.8.1. Database Management

The database page allows admins to perform the following operations:

- View, add, edit, and delete words
- View, add, edit, and delete documents
- View, add, edit, and delete references


### 5.8.2. Bulk Data Upload
The bulk upload page allows admins to add or update words in bulk by uploading a Excel file. The Excel file must contain the following columns (case-sensitive) in order:
- id
- MLF
- English
- French
- Italian
- Spanish

The algorithm navigates through each row in the Excel file and checks if a word id is provided. If so, it adds the word to the database. If not, it updates the word with the provided translations (if the word exists). If the word does not exist, it is skipped.

### 5.8.3. OCR Processing

The OCR processing functionality allows admins to perform the following operations:
- Upload PDF documents
- Process uploaded PDF documents using OCRmyPDF
- View and download processed PDF/A documents (with a searchable text layer)
- Add the details of processed PDF documents to the database
- Add any new or existing words from the processed PDF documents to the database

Documents are processed on the server but are not stored or retained. Users are recommended to download the documents as soon as they are processed.

### 5.8.4. Account Management
Currently, only one admin user can be created. However, account management functionality is available for admins to manage their own accounts. Admins can perform the following operations:

- Change their email address
- Change their password

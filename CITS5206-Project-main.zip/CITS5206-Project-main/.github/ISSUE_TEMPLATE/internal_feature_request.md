---
name: Internal Feature Request
about: Suggest an idea or new feature for the project. For use by team members to standardize feature requests.
labels: internal, feature-request
---


## Category

- [ ] Backend/Server (Flask)
- [ ] Database (MySQL)
- [ ] Frontend/Client (HTML/CSS/JavaScript)
- [ ] CI/CD or Deployment
- [ ] Other (please specify)


## Assigned to

- [ ] Unassigned
- [ ] Assigned to: ________

## Priority

- [ ] Low
- [ ] Medium
- [ ] High
- [ ] Critical



# CITS5206-Project
This project is to develop a web application to support research on forms of a language termed the Mediterranean Lingua Franca throughout the history of Europe.

## Features
- **Search and Exploration**: Seamlessly search for MLF words, explore their historical context, and analyse linguistic trends.
- **Comprehensive Database**: Access a curated database of MLF words sourced from academic documents, complete with translations and historical data.
- **Interactive Visualizations**: Visualise word usage over time, explore geographical origins, and understand linguistic patterns thanks to direct integration with the HathiTrust Bookworm API.
- **Contribute to Research**: Contact the researcher to contribute to the project, suggest new words, and provide feedback.

## Getting Started
### Requirements
- [Python 3.9 or newer](https://www.python.org/downloads/)
- [Pip 21.1 or newer](https://pip.pypa.io/en/stable/installation/)
- [OCRmyPDF](https://github.com/ocrmypdf/OCRmyPDF) and its dependencies:
  - [Tesseract 4.1.1 or higher](https://tesseract-ocr.github.io/tessdoc/)
  - [Tesseract Language Data (English, French, Spanish, Italian)](https://github.com/tesseract-ocr/tessdat)
  - [Ghostscript 9.55 or newer](https://ghostscript.com/docs/9.54.0/)
  - [Unpaper 6.1](https://github.com/unpaper/unpaper)
- [Git](https://git-scm.com/downloads)
- [Virtualenv](https://virtualenv.pypa.io/en/latest/installation.html) (Optional)

These packages are not available on PyPI and must be installed separately. The easiest way to install them is by following the OS-specific [installation instructions](https://ocrmypdf.readthedocs.io/en/latest/installation.html) on the OCRmyPDF website. Make sure to install the Tesseract language data for English, French, Spanish, and Italian if they are not already present.

### Virtual Environment
It is recommended to use a virtual environment to run this project. To create a virtual environment, follow the instructions in the [Getting Started](./docs/Getting-Started.md) section. If you are using a virtual environment, make sure to activate it before installing the dependencies.

### Clone the Repository
To clone the repository, run the following command:
```
git clone https://github.com/ophixus/CITS5206-Project
```
### Install Dependencies
To install all the dependencies, run the following command:
```
cd CITS5206-Project
pip install -r requirements.txt
```
### Run the Application
To run the application, run the following command:
```
flask run
```
The application will be running on http://localhost:5000/ by default.

### Linting and Formatting
To lint the code, run the following command, with the option `--show-source` to show the source code of the errors and `--fix` to fix the errors automatically:
```
ruff check .
```
To format the code, run the following command, with the option `--check` to check if the code is formatted correctly and `--diff` to show the differences between the original and formatted code:
```
python -m black .
```
### Testing
To run the test suite, run the following command:
```
pytest
```
To run the Selenium tests, download the Selenium IDE extension for your browser and import the `tests/selenium/MLF.side` file. Make sure to log out of the application before running the tests.

### Accessing the API Documentation
The API documentation is available through SwaggerUI. You can access it by running the application and navigating to http://localhost:5000/docs. Alternatively, you can access the [API documentation](./docs/API-Documentation.md) in the documentation folder.

## User Guide
A detailed user guide is available in the [documentation folder](./docs/User-Guide.md). It contains instructions on how to use the application, including how to search for words, manage the database, and contact the researcher.

## Developer Guide
A detailed breakdown of the project's architecture and design is available in the [documentation folder](./docs/Introduction.md). It contains information on the project's structure, the technologies used, and how to extend or modify the application.

## Contributing
We welcome contributions from the community! Whether you're a developer, linguist, or researcher, you can contribute to the project's growth. Simply create a pull request or issue on GitHub, and we'll get back to you as soon as possible.

## License
This project is licensed under the Creative Commons. See the [LICENSE](./LICENSE) file for more information. However, please be aware that the project uses third-party libraries and dependencies that may be licensed differently. Please refer to the respective licenses of the libraries and dependencies for more information.
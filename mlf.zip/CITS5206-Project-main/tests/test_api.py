import pytest
from app import create_app, db
from app.models import Word, Document, User
from flask_login import login_user
from config import TestConfig
import json

# Define some test data
TEST_USER_USERNAME = "test_routes"
TEST_USER_EMAIL = "test_routes@example.com"
TEST_USER_PASSWORD = "password"


# Fixture for setting up the database
@pytest.fixture(scope="module")
def setup_database(app):
    with app.app_context():
        db.create_all()
        u = User(username=TEST_USER_USERNAME, email=TEST_USER_EMAIL)
        u.set_password(TEST_USER_PASSWORD)
        db.session.add(u)
        db.session.commit()
        yield db
        db.drop_all()


# Initialize the Flask application for testing
@pytest.fixture(scope="module")
def app():
    app = create_app(TestConfig)
    app.config["TESTING"] = True
    yield app


# Create a test client fixture
@pytest.fixture(scope="function")
def client(app):
    return app.test_client()


def test_get_all_words(client, setup_database):
    # Create a word in the database
    word = Word(mlf="MLF_Word_ALL", english="ENG_Word_ALL", french="FRE_Word_ALL")
    db.session.add(word)
    db.session.commit()

    # Make a request to get all words
    response = client.get("/api/word/all")

    # Check that the response is successful and contains the correct data
    assert response.status_code == 200
    assert response.json["data"][0]["mlf"] == "MLF_Word_ALL"
    assert response.json["data"][0]["english"] == "ENG_Word_ALL"


def test_get_word_by_text(client, setup_database):
    # Create a word in the database
    word = Word(mlf="MLF_Word_TEXT", english="ENG_Word_TEXT", french="FRE_Word_TEXT")
    db.session.add(word)
    db.session.commit()

    # Test case sensitive search
    response = client.get("/search?query=MLF_Word_TEXT", follow_redirects=True)
    print(response.data.decode("utf-8"))

    assert b"Search HathiTrust" in response.data

    # Test fuzzy search
    response = client.get("/search?query=Word")

    # Check the response status code
    assert response.status_code == 200

    # Check that the response contains the correct data
    assert b"MLF_Word_TEXT" in response.data
    assert b"ENG_Word_TEXT" in response.data


def test_get_word_by_id(client, setup_database):
    # Create a word in the database
    word = Word(mlf="MLF_Word_ID", english="ENG_Word_ID", french="FRE_Word_ID")
    db.session.add(word)
    db.session.commit()

    # Make a request to get the word by its ID
    response = client.get(f"/api/word/id/{word.id}")

    # Check that the response is successful and contains the correct data
    assert response.status_code == 200
    assert response.json["data"]["mlf"] == "MLF_Word_ID"
    assert response.json["data"]["english"] == "ENG_Word_ID"
    assert response.json["data"]["french"] == "FRE_Word_ID"

    # Check that the response return Not Found for nonexistant data
    response = client.get("/api/word/id/10000000")
    assert response.status_code == 404


def test_add_word(client, setup_database):
    with client.application.test_request_context():
        # Login as the test user
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Check that the user succesfully logged in
        response = client.get("/admin/index", follow_redirects=True)
        assert response.status_code == 200

        # Make a request to add a new word
        response = client.post(
            "/api/word/add",
            data=json.dumps(
                {
                    "english": "ENG_Word_ADD",
                    "mlf": "MLF_Word_ADD",
                    "french": "FRE_Word_ADD",
                    "italian": "ITA_Word_ADD",
                    "spanish": "SPA_Word_ADD",
                    "origin": "ORIGIN_ADD",
                    "references": [],
                }
            ),
            content_type="application/json",
        )

        # Check that the response is successful and contains the correct data
        assert response.status_code == 200
        assert response.json["data"]["mlf"] == "MLF_Word_ADD"
        assert response.json["data"]["english"] == "ENG_Word_ADD"
        assert response.json["data"]["french"] == "FRE_Word_ADD"
        assert response.json["data"]["italian"] == "ITA_Word_ADD"
        assert response.json["data"]["spanish"] == "SPA_Word_ADD"
        assert response.json["data"]["origin"] == "ORIGIN_ADD"
        assert response.json["data"]["references"] == []

        # Check that the word was added to the database
        word = Word.query.filter_by(mlf="MLF_Word_ADD").first()
        assert word.mlf == "MLF_Word_ADD"
        assert word.english == "ENG_Word_ADD"
        assert word.french == "FRE_Word_ADD"
        assert word.italian == "ITA_Word_ADD"
        assert word.spanish == "SPA_Word_ADD"
        assert word.origin == "ORIGIN_ADD"
        assert word.references == []


def test_update_word(client, setup_database):
    with client.application.test_request_context():
        # Login as the test user
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Check that the user succesfully logged in
        response = client.get("/admin/index", follow_redirects=True)
        assert response.status_code == 200

        # Create a word in the database
        word = Word(
            mlf="MLF_Word_UPDATE", english="ENG_Word_UPDATE", french="FRE_Word_UPDATE"
        )
        db.session.add(word)
        db.session.commit()

        # Get the word from the database to check id after it's updated
        word = Word.query.filter_by(mlf="MLF_Word_UPDATE").first()

        # Make a request to update the word
        response = client.put(
            "/api/word/update",
            data=json.dumps(
                {
                    "id": word.id,
                    "english": "ENG_Word_UPDATE2",
                    "mlf": "MLF_Word_UPDATE2",
                    "french": "FRE_Word_UPDATE2",
                    "italian": "ITA_Word_UPDATE2",
                    "spanish": "SPA_Word_UPDATE2",
                    "origin": "ORIGIN_UPDATE2",
                    "references": [],
                }
            ),
            content_type="application/json",
        )

        # Check that the response is successful and contains the correct data
        assert response.status_code == 200
        assert response.json["data"]["id"] == word.id
        assert response.json["data"]["mlf"] == "MLF_Word_UPDATE2"
        assert response.json["data"]["english"] == "ENG_Word_UPDATE2"
        assert response.json["data"]["french"] == "FRE_Word_UPDATE2"
        assert response.json["data"]["italian"] == "ITA_Word_UPDATE2"
        assert response.json["data"]["spanish"] == "SPA_Word_UPDATE2"
        assert response.json["data"]["origin"] == "ORIGIN_UPDATE2"
        assert response.json["data"]["references"] == []

        # Check that the word was updated in the database
        check_word = Word.query.filter_by(mlf="MLF_Word_UPDATE2").first()
        assert check_word.id == word.id
        assert check_word.mlf == "MLF_Word_UPDATE2"
        assert check_word.english == "ENG_Word_UPDATE2"
        assert check_word.french == "FRE_Word_UPDATE2"
        assert check_word.italian == "ITA_Word_UPDATE2"
        assert check_word.spanish == "SPA_Word_UPDATE2"
        assert check_word.origin == "ORIGIN_UPDATE2"
        assert check_word.references == []


def test_delete_word(client, setup_database):
    with client.application.test_request_context():
        # Login as the test user
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Check that the user succesfully logged in
        response = client.get("/admin/index", follow_redirects=True)
        assert response.status_code == 200

        # Create a word in the database
        word = Word(
            mlf="MLF_Word_DELETE", english="ENG_Word_DELETE", french="FRE_Word_DELETE"
        )
        db.session.add(word)
        db.session.commit()

        # Get the word from the database for the request
        word = Word.query.filter_by(mlf="MLF_Word_DELETE").first()

        # Make a request to delete the word
        response = client.delete(
            "/api/word/delete",
            data=json.dumps({"id": word.id}),
            content_type="application/json",
        )

        # Check that the word was deleted from the database
        check_word = Word.query.filter_by(mlf="MLF_Word_DELETE").first()
        assert check_word is None


def test_get_all_documents(client, setup_database):
    # Create a document in the database
    document = Document(title="Test Document ALL")
    db.session.add(document)
    db.session.commit()

    # Make a request to get all documents
    response = client.get("/api/document/all")

    # Check that the response is successful and contains the correct data
    assert response.status_code == 200
    assert response.json["data"][0]["title"] == "Test Document ALL"


# NOTE Doesn't work
def test_search_documents(client, setup_database):
    # Create a document in the database
    document = Document(title="Test_Document_SEARCH")
    db.session.add(document)
    db.session.commit()

    # Make a request to get all documents
    # response = client.get('/api/document/search?query=Test_Document_SEARCH')

    # # Check that the response is successful and contains the correct data
    # assert response.status_code == 200
    # assert response.json['data'][0]['title'] == 'Test_Document_SEARCH'


def test_get_document_by_id(client, setup_database):
    # Create a document in the database
    document = Document(title="Test Document ID")
    db.session.add(document)
    db.session.commit()

    # Make a request to get the document by its ID
    response = client.get(f"/api/document/id/{document.id}")

    # Check that the response is successful and contains the correct data
    assert response.status_code == 200
    assert response.json["data"]["title"] == "Test Document ID"

    # Check that the response return 404 for nonexistant data
    response = client.get("/api/document/id/10000000")
    assert response.status_code == 404


def test_add_document(client, setup_database):
    with client.application.test_request_context():
        # Login as the test user
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Check that the user succesfully logged in
        response = client.get("/admin/index", follow_redirects=True)
        assert response.status_code == 200

        # Make a request to add a new document
        response = client.post(
            "/api/document/add",
            data=json.dumps(
                {
                    "year": "Test Year ADD",
                    "title": "Test Document ADD",
                    "author": "Test Author ADD",
                    "place": "Test Place ADD",
                    "genre": "Test Genre ADD",
                }
            ),
            content_type="application/json",
        )

        # Check that the response is successful and contains the correct data
        assert response.status_code == 200
        assert response.json["data"]["year"] == "Test Year ADD"
        assert response.json["data"]["title"] == "Test Document ADD"
        assert response.json["data"]["author"] == "Test Author ADD"
        assert response.json["data"]["place"] == "Test Place ADD"
        assert response.json["data"]["genre"] == "Test Genre ADD"

        # Check that the document was added to the database
        document = Document.query.filter_by(title="Test Document ADD").first()
        assert document.year == "Test Year ADD"
        assert document.title == "Test Document ADD"
        assert document.author == "Test Author ADD"
        assert document.place == "Test Place ADD"
        assert document.genre == "Test Genre ADD"


def test_update_document(client, setup_database):
    with client.application.test_request_context():
        # Login as the test user
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Check that the user succesfully logged in
        response = client.get("/admin/index", follow_redirects=True)
        assert response.status_code == 200

        # Create a document in the database
        document = Document(title="Test Document UPDATE")
        db.session.add(document)
        db.session.commit()

        # Get the document from the database to check id after it's updated
        document = Document.query.filter_by(title="Test Document UPDATE").first()

        # Make a request to update the document
        response = client.put(
            "/api/document/update",
            data=json.dumps(
                {
                    "id": document.id,
                    "year": "Test Year UPDATE2",
                    "title": "Test Document UPDATE2",
                    "author": "Test Author UPDATE2",
                    "place": "Test Place UPDATE2",
                    "genre": "Test Genre UPDATE2",
                }
            ),
            content_type="application/json",
        )

        # Check that the response is successful and contains the correct data
        assert response.status_code == 200
        assert response.json["data"]["id"] == document.id
        assert response.json["data"]["year"] == "Test Year UPDATE2"
        assert response.json["data"]["title"] == "Test Document UPDATE2"
        assert response.json["data"]["author"] == "Test Author UPDATE2"
        assert response.json["data"]["place"] == "Test Place UPDATE2"
        assert response.json["data"]["genre"] == "Test Genre UPDATE2"

        # Check that the document was updated in the database
        check_document = Document.query.filter_by(title="Test Document UPDATE2").first()
        assert check_document.id == document.id
        assert check_document.year == "Test Year UPDATE2"
        assert check_document.title == "Test Document UPDATE2"
        assert check_document.author == "Test Author UPDATE2"
        assert check_document.place == "Test Place UPDATE2"
        assert check_document.genre == "Test Genre UPDATE2"


def test_delete_document(client, setup_database):
    with client.application.test_request_context():
        # Login as the test user
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Check that the user succesfully logged in
        response = client.get("/admin/index", follow_redirects=True)
        assert response.status_code == 200

        # Create a document in the database
        document = Document(title="Test Document DELETE")
        db.session.add(document)
        db.session.commit()

        # Get the document from the database for the request
        document = Document.query.filter_by(title="Test Document DELETE").first()

        # Make a request to delete the document
        response = client.delete(
            "/api/document/delete",
            data=json.dumps({"id": document.id}),
            content_type="application/json",
        )

        # Check that the document was deleted from the database
        check_document = Document.query.filter_by(title="Test Document DELETE").first()
        assert check_document is None

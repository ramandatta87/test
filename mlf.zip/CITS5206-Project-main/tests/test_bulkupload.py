import pytest
from app import create_app, db
from app.models import User, Word
from flask_login import login_user
from config import TestConfig
import pandas as pd
import io

# Define some test data
TEST_USER_USERNAME = "test_routes"
TEST_USER_EMAIL = "test_routes@example.com"
TEST_USER_PASSWORD = "password"


# Fixture for setting up the database
@pytest.fixture(scope="module")
def setup_database(app):
    with app.app_context():
        db.create_all()
        u = User(username=TEST_USER_USERNAME, email=TEST_USER_EMAIL)
        u.set_password(TEST_USER_PASSWORD)
        db.session.add(u)
        db.session.commit()
        yield db
        db.drop_all()


# Initialize the Flask application for testing
@pytest.fixture(scope="module")
def app():
    app = create_app(TestConfig)
    app.config["TESTING"] = True
    yield app


# Create a test client fixture
@pytest.fixture(scope="function")
def client(app):
    return app.test_client()


# Test bulk upload with valid file
def test_bulk_upload_valid_file(client, setup_database):
    with client.application.test_request_context():
        # Test that bulk upload works with valid file
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Create a test file
        data = {
            "id": [1, 2, 3],
            "MLF": ["test1", "test2", "test3"],
            "English": ["test1", "test2", "test3"],
            "French": ["test1", "test2", "test3"],
            "Italian": ["test1", "test2", "test3"],
            "Spanish": ["test1", "test2", "test3"],
        }
        df = pd.DataFrame(data)
        file = io.BytesIO()
        writer = pd.ExcelWriter(file)
        df.to_excel(writer, sheet_name="Sheet1", index=False)
        writer.close()
        file.seek(0)

        response = client.post(
            "/admin/upload",
            data={"excel-file": (file, "test_file.xlsx")},
            content_type="multipart/form-data",
            follow_redirects=True,
        )

        assert response.status_code == 200
        assert b"uploaded and processed successfully!" in response.data

        # Check that the words were added to the database
        assert Word.query.filter_by(id=1).first().english == "test1"
        assert Word.query.filter_by(id=2).first().english == "test2"
        assert Word.query.filter_by(id=3).first().english == "test3"


# Test bulk upload with database update
def test_bulk_upload_database_update(client, setup_database):
    with client.application.test_request_context():
        # Test that bulk upload updates the database
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Create a test file
        data = {
            "id": [1, 2, 3],
            "MLF": ["test1", "test2", "test3"],
            "English": ["test1", "test2", "test3"],
            "French": ["test1", "test2", "test3"],
            "Italian": ["test1", "test2", "test3"],
            "Spanish": ["test1", "test2", "test3"],
        }
        df = pd.DataFrame(data)
        file = io.BytesIO()
        writer = pd.ExcelWriter(file)
        df.to_excel(writer, sheet_name="Sheet1", index=False)
        writer.close()
        file.seek(0)

        response = client.post(
            "/admin/upload",
            data={"excel-file": (file, "test_file.xlsx")},
            content_type="multipart/form-data",
            follow_redirects=True,
        )

        assert response.status_code == 200
        assert b"uploaded and processed successfully!" in response.data

        # Check that the database has been updated
        assert Word.query.filter_by(id=1).first().english == "test1"
        assert Word.query.filter_by(id=2).first().english == "test2"
        assert Word.query.filter_by(id=3).first().english == "test3"

        # Update the test file
        data = {
            "id": [1, 2, 3],
            "MLF": ["test1_updated", "test2", "test3"],
            "English": ["test1_updated", "test2", "test3"],
            "French": ["test1_updated", "test2", "test3"],
            "Italian": ["test1_updated", "test2", "test3"],
            "Spanish": ["test1_updated", "test2", "test3"],
        }
        df = pd.DataFrame(data)
        file = io.BytesIO()
        writer = pd.ExcelWriter(file)
        df.to_excel(writer, sheet_name="Sheet1", index=False)
        writer.close()
        file.seek(0)

        response = client.post(
            "/admin/upload",
            data={"excel-file": (file, "test_file.xlsx")},
            content_type="multipart/form-data",
            follow_redirects=True,
        )

        assert response.status_code == 200
        assert b"uploaded and processed successfully!" in response.data

        # Check that the database has been updated
        assert Word.query.filter_by(id=1).first().english == "test1_updated"
        assert Word.query.filter_by(id=2).first().english == "test2"
        assert Word.query.filter_by(id=3).first().english == "test3"


# Test bulk upload with invalid file
def test_bulk_upload_invalid_file(client, setup_database):
    with client.application.test_request_context():
        # Test that bulk upload works with invalid file
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Create a test file
        data = {
            "id": [1, 2, 3],
            "MLF": ["test1", "test2", "test3"],
            "English": ["test1", "test2", "test3"],
            "French": ["test1", "test2", "test3"],
            "Italian": ["test1", "test2", "test3"],
        }
        df = pd.DataFrame(data)
        file = io.BytesIO()
        writer = pd.ExcelWriter(file)
        df.to_excel(writer, sheet_name="Sheet1", index=False)
        writer.close()
        file.seek(0)

        response = client.post(
            "/admin/upload",
            data={"excel-file": (file, "test_file.xlsx")},
            content_type="multipart/form-data",
            follow_redirects=True,
        )

        assert response.status_code == 200
        assert (
            b"Error: Column names are not in the correct order/invalid, please check"
            b" the file." in response.data
        )


# Test bulk upload with missing file
def test_bulk_upload_missing_file(client, setup_database):
    with client.application.test_request_context():
        # Test that bulk upload works with missing file
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        response = client.post("/admin/upload", data={}, follow_redirects=True)

        assert response.status_code == 200
        assert b"Bulk Upload" in response.data


# Test bulk upload with missing id column
def test_bulk_upload_missing_id_column(client, setup_database):
    with client.application.test_request_context():
        # Test that bulk upload works with missing id column
        actual_user = User.query.filter_by(username=TEST_USER_USERNAME).first()
        login_user(actual_user)

        # Create a test file
        data = {
            "MLF": ["test1", "test2", "test3"],
            "English": ["test1", "test2", "test3"],
            "French": ["test1", "test2", "test3"],
            "Italian": ["test1", "test2", "test3"],
            "Spanish": ["test1", "test2", "test3"],
        }
        df = pd.DataFrame(data)
        file = io.BytesIO()
        writer = pd.ExcelWriter(file)
        df.to_excel(writer, sheet_name="Sheet1", index=False)
        writer.close()
        file.seek(0)

        response = client.post(
            "/admin/upload",
            data={"excel-file": (file, "test_file.xlsx")},
            content_type="multipart/form-data",
            follow_redirects=True,
        )

        assert response.status_code == 200
        assert b"does not contain the id column." in response.data

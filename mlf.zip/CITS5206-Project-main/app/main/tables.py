from flask import request
from app.datatables import DataColumn, DataTable
from app.models import Word, Document
from app.main import bp

# Glossary table
glossary = DataTable(
    model=Word,
    columns=[
        DataColumn("mlf", Word.mlf),
        DataColumn("english", Word.english, searchable=False),
        DataColumn("id", Word.id, sortable=False, searchable=False),
    ],
)

# Documents table
corpora = DataTable(
    model=Document,
    columns=[
        DataColumn("year", Document.year),
        DataColumn("title", Document.title),
        DataColumn("author", Document.author),
        DataColumn("place", Document.place),
        DataColumn("genre", Document.genre),
    ],
)


# Get data for the glossary page
@bp.get("/glossary_table")
def get_glossary_table():
    # Check if search value is a regex
    search = request.args.get("search[value]")
    if search and search[0] == "^":
        return glossary.refresh(request, regex=True)
    else:
        return glossary.refresh(request)


# Get data for the documents page
@bp.get("/corpora_table")
def get_corpora_table():
    return corpora.refresh(request)

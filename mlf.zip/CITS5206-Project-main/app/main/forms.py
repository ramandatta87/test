from flask_wtf import FlaskForm
from wtforms import StringField, BooleanField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Email, Length


# Form to contact the site owner
class ContactForm(FlaskForm):
    first_name = StringField("First Name", validators=[DataRequired()])
    last_name = StringField("Last Name", validators=[DataRequired()])
    email = StringField("Email", validators=[DataRequired(), Email()])
    # validators=[] is for making the field optional
    user_type = SelectField(
        "User Type",
        choices=[
            ("institution", "Institution"),
            ("researcher", "Researcher"),
            ("student", "Student"),
            ("professional", "Professional"),
            ("hobbyist", "Hobbyist"),
            ("other", "Other"),
        ],
        validators=[],
    )

    # ... other fields ...
    message = TextAreaField("Message", validators=[DataRequired(), Length(max=500)])
    agree = BooleanField(
        "I agree to be contacted using the provided details and understand that my use"
        " of this contact form is subject to responsible and reasonable communication"
        " practices, with no guaranteed response",
        validators=[DataRequired()],
    )
    submit = SubmitField("Submit")

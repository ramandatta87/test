from flask import render_template, redirect, url_for, flash, request
from app.models import Word
from app.main import bp
from app.main.forms import ContactForm
from app.main.email import send_contact_email
from app.api.words import _get_word_by_text


# Home page
@bp.route("/")
@bp.route("/index")
def index():
    return render_template("main/index.html", title="MLF Database")


# About page
@bp.route("/about")
def about():
    return render_template("main/about.html", title="About")


# Corpora page
@bp.route("/corpora")
def corpora():
    return render_template("main/corpora.html", title="Corpora")


# Glossary page
@bp.route("/glossary")
def glossary():
    return render_template("main/glossary.html", title="Glossary")


# Search page
@bp.route("/search", methods=["GET"])
def search(query=None, results=None):
    query = request.args.get("query")
    if query:
        data = _get_word_by_text({"text": query}).get("data", {})
        exact_match = data.get("exact_match", False)
        results = data.get("words", [])
        if exact_match:
            return redirect(url_for("main.word", id=results[0].get("id")))
    return render_template(
        "main/search.html", query=query, results=results, title="Search"
    )


# Dynamic word page
@bp.route("/word", methods=["GET"])
def word():
    id = request.args.get("id")
    w = Word.query.filter_by(id=id).first_or_404()
    results = w.serialize()
    title = results.get("mlf", f"Word {id}")
    return render_template("main/word.html", id=id, results=results, title=title)


# Contact us page
@bp.route("/contact", methods=["GET", "POST"])
def contact():
    form = ContactForm()  # Create form object

    if form.validate_on_submit():
        # Get form data
        name = form.first_name.data + " " + form.last_name.data
        email = form.email.data
        user_type = form.user_type.data
        message = form.message.data

        # Check if the "agree" checkbox is checked
        if not form.agree.data:
            flash("Please agree to the terms before submitting.", "danger")
            return redirect(url_for("main.contact"))

        # Create the email message
        _, status_code = send_contact_email(name, email, user_type, message)

        # Check if email is sent successfully
        if status_code == 202:
            flash("Message sent successfully.", "success")
        else:
            flash(f"Failed to send email. Status code: {status_code}", "danger")
        return redirect(url_for("main.contact"))

    # Form validation failed, debug and display errors
    elif form.errors:
        flash(f"Form validation failed! error message is: {str(form.errors)}", "danger")
    return render_template("main/contact.html", title="Contact Us", form=form)

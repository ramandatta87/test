from flask import render_template
from app.email import send_email
from config import Config


def send_contact_email(name, email, user_type, message):
    r, sc = send_email(
        subject="[MLF Database] New Contact Form Submission",
        sender=Config.SENDER_EMAIL,
        recipients=Config.ADMIN_EMAIL,
        html_content=render_template(
            "email/contact_message.html",
            name=name,
            email=email,
            user_type=user_type,
            message=message,
        ),
    )
    return r, sc

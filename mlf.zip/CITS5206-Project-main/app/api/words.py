from flask_login import login_required
from sqlalchemy import func
from app import db
from app.models import Word, Document
from app.api.schemas import (
    WordSchema,
    AddWordSchema,
    RequestById,
    RequestByText,
    WordByTextResponse,
)
from app.api import bp


# Get all words
@bp.get("/word/all")
@bp.output(WordSchema(many=True))
def get_all_words():
    words = Word.query.all()
    return {
        "data": [w.serialize() for w in words],
        "status_code": 200,
        "message": "Successfully retrieved all words.",
    }


# Get word by text
@bp.get("/word/search")
@bp.input(RequestByText, location="query")
@bp.output(WordByTextResponse)
def get_word_by_text(query_data):
    return _get_word_by_text(query_data)


# Get word by text - Internal
def _get_word_by_text(query_data):
    # Case sensitive search
    text = query_data["text"]
    exact = True
    words = Word.query.filter(
        (func.lower(Word.english) == func.lower(text))
        | (func.lower(Word.mlf) == func.lower(text))
        | (func.lower(Word.french) == func.lower(text))
        | (func.lower(Word.italian) == func.lower(text))
        | (func.lower(Word.spanish) == func.lower(text))
    ).all()

    # Fuzzy search
    if not words:
        exact = False
        search_term = f"%{text.lower()}%"
        words = Word.query.filter(
            (func.lower(Word.english).like(search_term))
            | (func.lower(Word.mlf).like(search_term))
            | (func.lower(Word.french).like(search_term))
            | (func.lower(Word.italian).like(search_term))
            | (func.lower(Word.spanish).like(search_term))
        ).all()

    # Return the words
    data = {"words": [w.serialize() for w in words], "exact_match": exact}
    return {
        "data": data,
        "status_code": 200,
        "message": f"Retrieved {len(words)} words.",
    }


# Get word by ID
@bp.get("/word/id/<int:id>")
@bp.output(WordSchema)
def get_word_by_id(id):
    # Check if word exists
    word = db.get_or_404(Word, id)
    # Return the word
    return {
        "data": word.serialize(),
        "status_code": 200,
        "message": "Successfully retrieved word.",
    }


# Add a new word
@bp.post("/word/add")
@bp.input(AddWordSchema)
@bp.output(WordSchema)
@login_required
def add_word(json_data):
    return _add_word(json_data)


# Add a new word - Internal
def _add_word(json_data):
    print("response", json_data)
    # Create the word
    word = Word(
        english=json_data["english"],
        mlf=json_data["mlf"],
        french=json_data["french"],
        italian=json_data["italian"],
        spanish=json_data["spanish"],
        origin=json_data["origin"],
        references=[],
    )

    # Add references
    references = json_data["references"]
    for ref in references:
        document = Document.query.get(int(ref))
        if document:
            word.references.append(document)

    # Commit and return
    db.session.add(word)
    db.session.commit()
    return {
        "data": word.serialize(),
        "status_code": 201,
        "message": "Successfully added word.",
    }


# Update a word
@bp.put("/word/update")
@bp.input(WordSchema)
@bp.output(WordSchema)
@login_required
def update_word(json_data):
    return _update_word(json_data)


# Update a word - Internal
def _update_word(json_data):
    # Check if word exists
    word = db.get_or_404(Word, json_data["id"])

    # Update the word
    word.english = json_data["english"]
    word.mlf = json_data["mlf"]
    word.french = json_data["french"]
    word.italian = json_data["italian"]
    word.spanish = json_data["spanish"]
    word.origin = json_data["origin"]

    # Update references
    current_references = [ref.id for ref in word.references]
    new_references = [int(ref) for ref in json_data.get("references", [])]
    for ref in new_references:
        if ref not in current_references:
            word.references.append(Document.query.get(ref))
    for ref in current_references:
        if ref not in new_references:
            word.references.remove(Document.query.get(ref))

    # Commit and return
    db.session.commit()
    return {
        "data": word.serialize(),
        "status_code": 200,
        "message": "Successfully updated word.",
    }


# Delete a word by ID
@bp.delete("/word/delete")
@bp.input(RequestById)
@bp.output({})
@login_required
def delete_word(json_data):
    _delete_word(json_data)


# Delete a word by ID - Internal
def _delete_word(json_data):
    # Check if word exists
    word = db.get_or_404(Word, json_data["id"])
    # Delete the word
    db.session.delete(word)
    db.session.commit()
    return {"data": {}, "status_code": 204, "message": "Successfully deleted word."}

from apiflask import Schema
from apiflask.fields import Integer, List, Raw, String, Boolean, Nested


# Word base schema
class BaseWordSchema(Schema):
    mlf = String(default="")
    english = String(default="")
    french = String(default="")
    italian = String(default="")
    spanish = String(default="")
    origin = String(default="")
    references = List(Raw(), default=[])


# Word schema
class WordSchema(BaseWordSchema):
    id = Integer(required=True)


# Word add schema
class AddWordSchema(BaseWordSchema):
    pass


# Word response to search by text
class WordByTextResponse(Schema):
    words = List(Nested(WordSchema), default=[])
    exact_match = Boolean(default=True)


# Document base schema
class BaseDocumentSchema(Schema):
    year = String(default="")
    title = String(default="")
    author = String(default="")
    place = String(default="")
    genre = String(default="")


# Document schema
class DocumentSchema(BaseDocumentSchema):
    id = Integer(required=True)


# Document add schema
class AddDocumentSchema(BaseDocumentSchema):
    pass


# Document response to search by text
class DocumentByTextResponse(Schema):
    documents = List(Nested(DocumentSchema), default=[])
    exact_match = Boolean(default=True)


# Generic request schemas
class RequestById(Schema):
    id = Integer(required=True)


class RequestByText(Schema):
    text = String(default=None)

from flask import url_for
from flask_wtf import FlaskForm
from wtforms import (
    StringField,
    PasswordField,
    SubmitField,
    FieldList,
    FormField,
    BooleanField,
    IntegerField,
)
from wtforms.validators import DataRequired, Email, EqualTo, Optional
from wtforms_sqlalchemy.fields import QuerySelectMultipleField, QuerySelectField
from markupsafe import Markup
import re
from app.models import Document, Word
from app import db


# Form for changing email
class ChangeEmailForm(FlaskForm):
    email = StringField("New Email", validators=[DataRequired(), Email()])
    submit = SubmitField("Change Email")


# Form for changing password
class ChangePasswordForm(FlaskForm):
    password = PasswordField("Password", validators=[DataRequired()])
    password2 = PasswordField(
        "Repeat Password", validators=[DataRequired(), EqualTo("password")]
    )
    submit = SubmitField("Request Password Reset")


# Form for adding a word
class AddWordForm(FlaskForm):
    mlf = StringField("MLF", validators=[DataRequired()])
    english = StringField("English")
    french = StringField("French")
    italian = StringField("Italian")
    spanish = StringField("Spanish")
    origin = StringField("Origin")
    references = QuerySelectMultipleField(
        "Reference",
        query_factory=lambda: Document.query.all(),
        get_label="title",
        allow_blank=True,
        blank_text="No references",
        default=[],
    )
    submit = SubmitField("Add Word")


# Form for changing a word
class UpdateWordForm(FlaskForm):
    id = IntegerField(
        "Word ID", validators=[DataRequired()], render_kw={"readonly": True}
    )
    mlf = StringField("MLF", validators=[DataRequired()])
    english = StringField("English")
    french = StringField("French")
    italian = StringField("Italian")
    spanish = StringField("Spanish")
    origin = StringField("Origin")
    references = QuerySelectMultipleField(
        "Reference",
        query_factory=lambda: Document.query.all(),
        get_label="title",
        allow_blank=True,
        blank_text="No references",
        default=[],
    )
    submit = SubmitField("Update Word")


# Form for deleting a word
class DeleteWordForm(FlaskForm):
    id = IntegerField(
        "Word ID", validators=[DataRequired()], render_kw={"readonly": True}
    )
    mlf = StringField("MLF", render_kw={"readonly": True})
    english = StringField("English", render_kw={"readonly": True})
    french = StringField("French", render_kw={"readonly": True})
    italian = StringField("Italian", render_kw={"readonly": True})
    spanish = StringField("Spanish", render_kw={"readonly": True})
    origin = StringField("Origin", render_kw={"readonly": True})
    references = QuerySelectMultipleField(
        "Reference",
        query_factory=lambda: Document.query.all(),
        get_label="title",
        render_kw={"readonly": True},
        allow_blank=True,
        blank_text="No references",
        default=[],
    )
    submit = SubmitField("Delete Word")


# Form for adding a document
class AddDocumentForm(FlaskForm):
    year = StringField("Year")
    title = StringField("Title", validators=[DataRequired()])
    author = StringField("Author")
    place = StringField("Place")
    genre = StringField("Genre")
    submit = SubmitField("Add Document")


# Form for changing a document
class UpdateDocumentForm(FlaskForm):
    id = IntegerField(
        "Document ID", validators=[DataRequired()], render_kw={"readonly": True}
    )
    year = StringField("Year")
    title = StringField("Title", validators=[DataRequired()])
    author = StringField("Author")
    place = StringField("Place")
    genre = StringField("Genre")
    submit = SubmitField("Update Document")


# Form for deleting a document
class DeleteDocumentForm(FlaskForm):
    id = IntegerField(
        "Document ID", validators=[DataRequired()], render_kw={"readonly": True}
    )
    year = StringField("Year", render_kw={"readonly": True})
    title = StringField("Title", render_kw={"readonly": True})
    author = StringField("Author", render_kw={"readonly": True})
    place = StringField("Place", render_kw={"readonly": True})
    genre = StringField("Genre", render_kw={"readonly": True})
    submit = SubmitField("Delete Document")


# Document form for the annotate page
class Annotate_DocumentForm(FlaskForm):
    year = StringField("Year", validators=[Optional()])
    title = StringField("Title", validators=[Optional()])
    author = StringField("Author", validators=[Optional()])
    place = StringField("Place", validators=[Optional()])
    genre = StringField("Genre", validators=[Optional()])


# Word table row
class WordRow(FlaskForm):
    mlf = StringField("MLF", validators=[Optional()])
    english = StringField("English", validators=[Optional()])
    french = StringField("French", validators=[Optional()])
    italian = StringField("Italian", validators=[Optional()])
    spanish = StringField("Spanish", validators=[Optional()])


# Custom table widget
class WordTableWidget(object):
    # Initialize the widget
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    # Generate the html for a table row
    def _generate_row(self, form, row_tag=True):
        html = []
        hidden = ""
        for subfield in form:
            if subfield.type not in ["CSRFTokenField", "SubmitField", "HiddenField"]:
                html.append("<td>%s%s</td>" % (hidden, str(subfield)))
                hidden = ""
            else:
                hidden += str(subfield)
        delete = url_for("static", filename="icons/delete.svg")
        add = url_for("static", filename="icons/add.svg")
        html.append(
            '<td>%s<button class="btn icon-btn" style="background-image: url(%s);"'
            ' type="button" onclick="addRow(this);"></button>' % (hidden, add)
        )
        html.append(
            '<button class="btn icon-btn" style="background-image: url(%s);"'
            ' type="button" onclick="deleteRow(this);"></button></td>' % delete
        )
        if row_tag:
            html = ["<tr>"] + html + ["</tr>"]
        return "".join(html)

    # Generate the html for the table header
    def _generate_header(self, form):
        html = []
        for subfield in form:
            if subfield.type not in ["CSRFTokenField", "SubmitField", "HiddenField"]:
                html.append('<th scope="col">%s</th>' % subfield.label.text)
        return "".join(html)

    # Render the widget
    def __call__(self, field, **kwargs):
        # Render the header and first row
        html = [
            '<table class="table table-sm table-hover" id="word-table"><thead'
            ' id="word-table-header"><tr>'
        ]
        template = self._generate_row(field[0], row_tag=False)
        html.append(
            self._generate_header(field[0])
            + '</tr></thead><tbody id="word-table-body"><tr>'
            + template
            + "</tr>"
        )
        # Clean up the template
        re.sub(r'value="[^"]*"', 'value=""', template)
        # Render the rest of the rows
        for index, form in enumerate(field):
            if index > 0:
                html.append(self._generate_row(form))
        # Close the table and add the scripts
        html.append(
            """</tbody></table><script>
            var table = document.getElementById('word-table');
            var tableBody = document.getElementById('word-table-body');
            
            function getRowNumber(row) {
                var el = row.querySelectorAll('input, select')[0];
                if (el != null) {
                    var match = el.id.match(/new_words-(\\d+)-/);
                    return match.length > 1 ? parseInt(match[1]) : row.rowIndex;
                }
                else {
                    return row.rowIndex;
                }
            }
            
            function resetRowNumbers(index, number) {
                var rows = table.rows;
                for (var i = index; i < rows.length; i++) {
                    var row = rows[i];
                    row.querySelectorAll('input, select').forEach(function(element) {
                        element.id = element.id.replace(/new_words-(\\d+)-/g, 
                            'new_words-' + number + '-');
                        element.name = element.name.replace(/new_words-(\\d+)-/g, 
                            'new_words-' + number + '-');
                    });
                    number++
                };
            }
            
            function addRow(button) {
                var row = button.closest('tr');
                var rowIndex = row.rowIndex;
                var number = getRowNumber(row);
                var template =' """
            + template
            + """ ';
                template = template.replace(/new_words-\\d+-/g, 'new_words-' 
                    + (number + 1) + '-');
                table.insertRow(rowIndex + 1).innerHTML = template;
                resetRowNumbers(rowIndex + 2, number + 2);
            };
                
            function deleteRow(button) {
                var row = button.closest('tr');
                if (tableBody.rows.length <= 1) {
                    row.querySelectorAll('input, select').forEach(function(element) 
                        { element.value = '' });
                } else {
                    var number = getRowNumber(row);
                    var rowIndex = row.rowIndex;
                    table.deleteRow(rowIndex);
                    resetRowNumbers(rowIndex, number);
                };
            };
        </script>"""
        )
        return Markup("".join(html))


# Annotate doument form
class AnnotateForm(FlaskForm):
    document = QuerySelectField(
        "Select a document:",
        query_factory=lambda: Document.query.all(),
        get_label="title",
        validators=[Optional()],
        render_kw={"size": 18},
        allow_blank=True,
        blank_text="None",
    )
    new_document = FormField(Annotate_DocumentForm)
    document_type = BooleanField(
        "Document", default=True, render_kw={"style": "display: none;"}
    )  # Hidden field
    words = QuerySelectMultipleField(
        "Words",
        query_factory=lambda: [Word()]
        + db.session.query(Word).filter(Word.mlf != "").all(),
        get_label="mlf",
        render_kw={"size": 5},
        validators=[Optional()],
    )
    new_words = FieldList(
        FormField(WordRow),
        min_entries=1,
        max_entries=100,
        widget=WordTableWidget(),
        validators=[Optional()],
    )
    submit = SubmitField("Submit")

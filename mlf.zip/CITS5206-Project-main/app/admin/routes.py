from flask import render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from app.admin import bp
from app.admin.forms import ChangeEmailForm, ChangePasswordForm, AnnotateForm
from app.admin.forms import (
    AddWordForm,
    AddDocumentForm,
    UpdateWordForm,
    UpdateDocumentForm,
    DeleteWordForm,
    DeleteDocumentForm,
)
from app.models import Document, Word
from app.api.words import _add_word, _update_word, _delete_word
from app.api.documents import _add_document, _update_document, _delete_document
import re


# Home page
@bp.route("/")
@bp.route("/index")
@login_required
def index():
    return render_template("admin/index.html", title="Admin Home")


# Database page
@bp.route("/database", methods=["GET", "POST"])
@login_required
def database():
    # Create form objects
    add_word_form = AddWordForm()
    update_word_form = UpdateWordForm()
    delete_word_form = DeleteWordForm()
    add_document_form = AddDocumentForm()
    update_document_form = UpdateDocumentForm()
    delete_document_form = DeleteDocumentForm()

    if request.method == "POST":
        # Get the action from the post request str
        form = request.form["form"]

        if (
            form == "add-word" and add_word_form.validate_on_submit()
        ):  # If form is submitted and validated
            data = {x: add_word_form[x].data for x in add_word_form._fields}
            data["references"] = [ref.id for ref in data["references"]]
            return _add_word(data)

        if (
            form == "update-word" and update_word_form.validate_on_submit()
        ):  # If form is submitted and validated
            data = {x: update_word_form[x].data for x in update_word_form._fields}
            data["references"] = [ref.id for ref in data["references"]]
            return _update_word(data)

        if (
            form == "delete-word" and delete_word_form.validate_on_submit()
        ):  # If form is submitted and validated
            data = {x: delete_word_form[x].data for x in delete_word_form._fields}
            data["references"] = [ref.id for ref in data["references"]]
            return _delete_word(data)

        if (
            form == "add-document" and add_document_form.validate_on_submit()
        ):  # If form is submitted and validated
            data = {x: add_document_form[x].data for x in add_document_form._fields}
            return _add_document(data)

        if (
            form == "update-document" and update_document_form.validate_on_submit()
        ):  # If form is submitted and validated
            data = {
                x: update_document_form[x].data for x in update_document_form._fields
            }
            return _update_document(data)

        if (
            form == "delete-document" and delete_document_form.validate_on_submit()
        ):  # If form is submitted and validated
            data = {
                x: delete_document_form[x].data for x in delete_document_form._fields
            }
            return _delete_document(data)

    # Add forms to a dictionary
    forms = {
        "Add Word": add_word_form,
        "Update Word": update_word_form,
        "Delete Word": delete_word_form,
        "Add Document": add_document_form,
        "Update Document": update_document_form,
        "Delete Document": delete_document_form,
    }

    # Render the database page and pass it the forms
    return render_template("admin/database.html", title="Database", forms=forms)


# Bulk upload page
@bp.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    # Required when navigating to the bulk upload page
    if "excel-file" not in request.files:
        return render_template("admin/upload.html", title="Bulk Upload")

    uploaded_file = request.files["excel-file"]
    # Check if file was provided
    if uploaded_file.filename == "":
        flash("Error: No file selected.", "danger")
        return render_template("admin/upload.html", title="Bulk Upload")

    # Read the file contents and convert them to a DataFrame
    import pandas as pd

    try:
        # Read the Excel file into a DataFrame
        df = pd.read_excel(uploaded_file)
        df.set_index("id", inplace=True)  # Set 'id' as the primary key

        # Check if the required headers are present and in the correct order
        required_headers = ["MLF", "English", "French", "Italian", "Spanish"]

        if list(df.columns) != required_headers:
            flash(
                "Error: Column names are not in the correct order/invalid, please check"
                " the file.",
                "danger",
            )
            return render_template("admin/upload.html", title="Bulk Upload")

        # Loop through the rows and add them to the database
        for index, row in df.iterrows():
            existing_record = Word.query.filter_by(id=index).first()

            # If the record already exists, update it
            if existing_record:
                print(
                    existing_record.english, existing_record.french, existing_record.mlf
                )
                existing_record.english = row["English"]
                existing_record.mlf = row["MLF"]
                existing_record.french = row["French"]
                existing_record.italian = row["Italian"]
                existing_record.spanish = row["Spanish"]
            else:
                new_record = Word(
                    id=index,
                    english=row["English"],
                    mlf=row["MLF"],
                    french=row["French"],
                    italian=row["Italian"],
                    spanish=row["Spanish"],
                )
                db.session.add(new_record)
            db.session.commit()

        # File uploaded and processed successfully
        flash(
            f'File "{uploaded_file.filename}" uploaded and processed successfully!',
            "success",
        )
    except KeyError:
        flash(
            f'Error: File "{uploaded_file.filename}" does not contain the id column.',
            "danger",
        )
    except ValueError:
        flash(
            f'Error: File "{uploaded_file.filename}" may contain invalid values.',
            "danger",
        )
    except Exception as e:
        flash(f"Error while processing the Excel file: {str(e)}", "danger")

    return render_template("admin/upload.html", title="Bulk Upload")


# Annotation page
@bp.route("/annotate", methods=["GET", "POST"])
@login_required
def annotate():
    # Create form object
    form = AnnotateForm()
    if request.method == "POST":
        if form.validate_on_submit():
            # Check if it is a new document or an existing one
            is_new_doc = form.document_type.data
            document = None
            # If it is a new document
            if is_new_doc:
                # Only add the document if the fields are not empty
                doc = form.new_document.data
                count = 0
                for d in doc.values():
                    if not d.strip():
                        count += 1
                if count != len(doc):
                    document = Document(
                        year=doc.get("year"),
                        title=doc.get("title"),
                        author=doc.get("author"),
                        place=doc.get("place"),
                        genre=doc.get("genre"),
                    )
                    db.session.add(document)
            # If it is an existing document
            else:
                document = Document.query.get(form.document.data.id)
            # Link existing words to the document
            for word in form.words.data:
                # Get the word from the database
                w = Word.query.get(word.id)
                if w and document:
                    w.references.append(document)
            # Add new words to the database
            for word in form.new_words.data:
                # Only add the word if the fields are not empty
                count = 0
                for w in word.values():
                    if not w.strip():
                        count += 1
                if count != len(word):
                    w = Word(
                        mlf=word.get("mlf"),
                        english=word.get("english"),
                        french=word.get("french"),
                        italian=word.get("italian"),
                        spanish=word.get("spanish"),
                    )
                    if document:
                        w.references.append(document)
                db.session.add(w)
            # Commit changes to the database
            db.session.commit()
            flash("Your changes have been saved.", "success")
        else:
            flash("There was an error with your submission.", "error")
        return redirect(url_for("admin.annotate"))
    return render_template("admin/annotate.html", title="Annotate", form=form)


# Account page
@bp.route("/account", methods=["GET", "POST"])
@login_required
def account():
    # Create form objects
    form_email = ChangeEmailForm()
    form_password = ChangePasswordForm()

    # Handle email form
    if form_email.validate_on_submit():
        email_data = form_email.email.data

        if current_user.email == email_data:
            flash("You are already using this email.", "danger")
            return redirect(url_for("admin.account"))

        current_user.change_email(email_data)
        db.session.commit()
        flash("Your email has been changed.", "success")
        return redirect(url_for("admin.account"))

    # Handle password form
    if form_password.validate_on_submit():
        password_data = form_password.password.data

        if len(password_data) < 8:
            flash("Password must be at least 8 characters long.", "danger")
            return redirect(url_for("admin.account"))

        if not re.search(r"[A-Z]", password_data):
            flash("Password must contain at least one uppercase letter.", "danger")
            return redirect(url_for("admin.account"))

        if not re.search(r"[!@#$%^&*()_+{}\[\]:;<>,.?~\\\-]", password_data):
            flash("Password must contain at least one special character.", "danger")
            return redirect(url_for("admin.account"))

        current_user.set_password(password_data)
        db.session.commit()
        flash("Your password has been changed.", "success")
        return redirect(url_for("admin.account"))

    # Render the account page and pass email and password forms
    return render_template(
        "admin/account.html",
        title="Account",
        form_email=form_email,
        form_password=form_password,
    )

from flask import request
from app.models import Word, Document
from app.datatables import DataColumn, DataTable
from app.admin import bp

# Word table
words = DataTable(
    model=Word,
    columns=[
        DataColumn("mlf", Word.mlf),
        DataColumn("english", Word.english),
        DataColumn("french", Word.french),
        DataColumn("italian", Word.italian),
        DataColumn("spanish", Word.spanish),
        DataColumn("origin", Word.origin),
        DataColumn("references", Word.references, sortable=False, searchable=False),
        DataColumn("id", Word.id, sortable=False, searchable=False),
    ],
)

# Document table
documents = DataTable(
    model=Document,
    columns=[
        DataColumn("year", Document.year),
        DataColumn("title", Document.title),
        DataColumn("author", Document.author),
        DataColumn("place", Document.place),
        DataColumn("genre", Document.genre),
        DataColumn("id", Document.id, sortable=False, searchable=False),
    ],
)


# Get word data for the database page
@bp.get("/word_table")
def get_word_table():
    return words.refresh(request)


# Get document data for the database page
@bp.get("/document_table")
def get_document_table():
    return documents.refresh(request)

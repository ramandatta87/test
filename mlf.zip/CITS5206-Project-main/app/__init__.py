from apiflask import APIFlask, Schema
from apiflask.fields import String, Integer, Field
from config import Config
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
import warnings
import flask_excel as excel


class BaseResponse(Schema):
    message = String()
    status_code = Integer()
    data = Field()


db = SQLAlchemy()
migrate = Migrate()
login = LoginManager()
login.login_view = "auth.login"
login.login_message = "Please log in to access this page."


def create_app(config_class=Config):
    app = APIFlask(__name__, title="MLF Database")
    app.config.from_object(config_class)
    app.config["BASE_RESPONSE_SCHEMA"] = BaseResponse
    app.description = (
        "API to support research on forms of a language termed the Mediterranean Lingua"
        " Franca throughout the history of Europe."
    )
    app.config["DOCS_FAVICON"] = "/static/icons/favicon.ico"
    app.config["SYNC_LOCAL_SPEC"] = True
    app.config["LOCAL_SPEC_PATH"] = "app/static/openapi.json"

    # Filter out Marshmallow warning
    warnings.filterwarnings(
        "ignore",
        message=(
            "Multiple schemas resolved to the name Generated. The name has been"
            " modified. Either manually add each of the schemas with a different name"
            " or provide a custom schema_name_resolver."
        ),
    )

    db.init_app(app)
    migrate.init_app(app, db)
    login.init_app(app)
    excel.init_excel(app)

    from app.main import bp as main_bp

    app.register_blueprint(main_bp)

    from app.admin import bp as admin_bp

    app.register_blueprint(admin_bp, url_prefix="/admin")

    from app.api import bp as api_bp

    app.register_blueprint(api_bp, url_prefix="/api")

    from app.auth import bp as auth_bp

    app.register_blueprint(auth_bp, url_prefix="/auth")

    return app

from config import Config
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

# Config SendGrid API
sg = SendGridAPIClient(api_key=Config.SENDGRID_API_KEY)


# Send email
def send_email(subject, sender, recipients, html_content):
    try:
        message = Mail(
            from_email=sender,
            to_emails=recipients,
            subject=subject,
            html_content=html_content,
        )
        response = sg.send(message)
        return response, response.status_code
    except Exception as e:
        return e, 500

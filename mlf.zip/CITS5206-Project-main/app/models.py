from app import db, login
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from time import time
from config import Config
import jwt


# User model with authentication methods
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, unique=True)
    email = db.Column(db.String(120), index=True, unique=True)
    password_hash = db.Column(db.String(128))  # Hashed password storage for security

    # Helper method for debugging
    def __repr__(self):
        return "<User {}>".format(self.username)

    # Change email address
    def change_email(self, email):
        self.email = email

    # Password setting and checking methods
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    # Reset password token generator
    def get_reset_password_token(self, expires_in=600):
        payload = {"reset_password": self.id, "exp": time() + expires_in}
        secret_key = Config.SECRET_KEY  # Assuming you have a 'SECRET_KEY' configuration
        token = jwt.encode(payload, secret_key, algorithm="HS256")
        return token

    @staticmethod
    def verify_reset_password_token(token):
        try:
            id = jwt.decode(token, Config.SECRET_KEY, algorithms=["HS256"])[
                "reset_password"
            ]
        except Exception:
            return
        return User.query.get(id)


# User loader function for Flask-Login (stores user session)
@login.user_loader
def load_user(id):
    return User.query.get(int(id))


# Table for mapping words to corpora
Reference = db.Table(
    "reference",
    db.Column("word_id", db.ForeignKey("word.id"), primary_key=True),
    db.Column("document_id", db.ForeignKey("document.id"), primary_key=True),
)


# Document model for corpora
class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.String(25))
    title = db.Column(db.String(255))
    author = db.Column(db.String(255))
    place = db.Column(db.String(255))
    genre = db.Column(db.String(255))

    def serialize(self):
        return {
            "id": self.id,
            "year": self.year,
            "title": self.title,
            "author": self.author,
            "place": self.place,
            "genre": self.genre,
        }

    def serialize_short(self):
        return {"id": self.id, "title": self.title}


# Word model
class Word(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    mlf = db.Column(db.String(255))
    english = db.Column(db.String(255))
    french = db.Column(db.String(255))
    italian = db.Column(db.String(255))
    spanish = db.Column(db.String(255))
    origin = db.Column(db.String(255))
    references = db.relationship("Document", secondary=Reference)

    def serialize(self):
        return {
            "id": self.id,
            "mlf": self.mlf,
            "english": self.english,
            "french": self.french,
            "italian": self.italian,
            "spanish": self.spanish,
            "origin": self.origin,
            "references": [document.serialize_short() for document in self.references],
        }

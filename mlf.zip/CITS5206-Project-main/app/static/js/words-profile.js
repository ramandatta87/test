document.addEventListener("DOMContentLoaded", function() {
    var map = L.map('map').setView([51.505, -0.09], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: 'Map data © OpenStreetMap contributors'
    }).addTo(map);

    // Call the function after Plotly.js is loaded
    loadJS('https://cdn.plot.ly/plotly-latest.min.js', plotTimeSeries);

});

function plotTimeSeries() {
    var trace = {
        type: 'scatter',
        mode: 'lines',
        x: ['2023-01-01', '2023-01-02', '2023-01-03'],  // Sample dates
        y: [10, 15, 13],  // Sample data points
        line: {shape: 'spline'}
    };

    var layout = {
        title: 'Sample Time Series Plot',
        xaxis: {
            type: 'date',
            title: 'Date'
        },
        yaxis: {
            title: 'Value'
        }
    };

    Plotly.newPlot('timeseries-plot', [trace], layout).then(function() {
        var svgElement = document.querySelector('#timeseries-plot svg');
        if (svgElement) {
            svgElement.style.backgroundColor = '#f6eee2';
        }
    });
}

function loadJS(src, callback) {
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = src;
    script.onload = callback; // Optional callback function if you want to execute something after the script is loaded
    document.body.appendChild(script);
}


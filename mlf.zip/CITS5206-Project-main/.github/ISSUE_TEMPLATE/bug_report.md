---
name: Bug\Trouble Report
about: Create a report to help us improve
labels: Bug\Trouble
---

## Bug\Trouble Report Checklist

Before submitting a new bug, please view the currently reported bugs [here](https://github.com/ophixus/CITS5206-Project/issues). If your bug has not been reported, please complete this report:

**NOTE: If you are submitting multiple bugs, please submit one report per bug**

*   [ ] I have checked the GitHub issues tracker and my bug has **NOT** been previously reported.
*   [ ] This report is for a single bug only, I will create a new report for additional bugs.
*   [ ] I have not included any sensitive information (passwords, API keys or system configuration information) as part of this report.

## Describe the Bug

A clear and concise description of what the bug\problem is.

## To Reproduce

Steps to reproduce the behavior:

1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

## Expected Behavior

A clear and concise description of what you expected to happen.

## Screenshots

If applicable, add screenshots to help explain your problem.

## Environment

- OS: [e.g., Windows, MacOS, Ubuntu]
- Browser: [e.g., Chrome, Safari]
- Version: [e.g., 22]
- Python Version: [3.8.x]
- Database Type:

## Additional Context

Add any other context about the problem here.

## Flask Server Logs


## MySQL Logs


## Front-end(HTML,CSS,Javascript) Errors (Console Logs\Screenshots)


## Possible Solution

If you have a solution or a proposal in mind, please share it.




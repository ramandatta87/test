import os

basedir = os.path.abspath(os.path.dirname(__file__))


class Config(object):
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL"
    ) or "sqlite:///" + os.path.join(basedir, "app", "MLF.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = (
        False  # Disable signals to app when database changes
    )
    SECRET_KEY = (
        os.environ.get("SECRET_KEY") or "super-secret-key-for-josh"
    )  # need to see if SECRET_KEY can be hidden somehow
    SENDER_EMAIL = "mlfdb2023@gmail.com"
    ADMIN_EMAIL = "mlfdb2023@gmail.com"
    JSON_AS_ASCII = False
    SENDGRID_API_KEY = (
        "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"
    )


class TestConfig(object):
    Testing = True
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL"
    ) or "sqlite:///" + os.path.join(basedir, "tests", "test.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = (
        False  # Disable signals to app when database changes
    )
    SECRET_KEY = (
        os.environ.get("SECRET_KEY") or "super-secret-key-for-josh"
    )  # need to see if SECRET_KEY can be hidden somehow
    SENDER_EMAIL = "mlfdb2023@gmail.com"
    ADMIN_EMAIL = "mlfdb2023@gmail.com"
    JSON_AS_ASCII = False
    SENDGRID_API_KEY = (
        "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"
    )

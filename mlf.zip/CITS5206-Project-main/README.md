# CITS5206-Project
This project is to develop a web application to support research on forms of a language termed the Mediterranean Lingua Franca throughout the history of Europe.

## Getting Started
### Requirements
- [Python 3.9 or newer](https://www.python.org/downloads/)
- [OCRmyPDF](https://github.com/ocrmypdf/OCRmyPDF) and its dependencies:
  - [Tesseract 4.1.1 or higher](https://tesseract-ocr.github.io/tessdoc/)
  - [Tesseract Language Data (English, French, Spanish, Italian)](https://github.com/tesseract-ocr/tessdat)
  - [Ghostscript 9.55 or newer](https://ghostscript.com/docs/9.54.0/)
  - [Unpaper 6.1](https://github.com/unpaper/unpaper)

These packages are not available on PyPI and must be installed separately. The easiest way to install them is by following the OS-specific [installation instructions](https://ocrmypdf.readthedocs.io/en/latest/installation.html) on the OCRmyPDF website. Make sure to install the Tesseract language data for English, French, Spanish, and Italian if they are not already present.

### Virtual Environment
It is recommended to use a virtual environment to run this project. To create a virtual environment, run the following command in the project directory:
```
python3 -m venv venv
```
To activate the virtual environment, run one of the following commands depending on your operating system:
```
source venv/bin/activate    # Linux or macOS
venv/Scripts/activate       # Windows
```
To deactivate the virtual environment, run the following command:
```
deactivate
```
### Install Dependencies
To install all the dependencies, run the following command:
```
pip install -r requirements.txt
```
### Run the Application
To run the application, run the following command:
```
flask run
```
The application will be running on http://localhost:5000/ by default.

### Linting and Formatting
To lint the code, run the following command, with the option `--show-source` to show the source code of the errors and `--fix` to fix the errors automatically:
```
ruff check .
```
To format the code, run the following command, with the option `--check` to check if the code is formatted correctly and `--diff` to show the differences between the original and formatted code:
```
python -m black .
```

### Accessing the API Documentation
The API documentation is available through SwaggerUI. You can access it by running the application and navigating to http://localhost:5000/docs.

### Run the test suite
To run the test suite, run the following command:
```
pytest
```

## Run the Selenium IDE test suite
To run the test suite, follow the instructions given below:

### Introduction
This document serves as a guide to run the test suite for the Flask application. The tests are automated using Selenium IDE, and the test suite is provided in the .side file format.

### Pre-requisites
Browser: Ensure you have a compatible web browser installed (e.g., Chrome, Firefox).
Selenium IDE: Install the Selenium IDE browser extension. You can find it for different browsers at https://www.selenium.dev/selenium-ide/

### Steps to Run the Test Suite
Install Selenium IDE:

Install the Selenium IDE browser extension for your preferred web browser.

Open Selenium IDE.

Click on the Import button.

Import the Test Suite from 
```
/CITS5206-Project/tests/MLF.side
```

### Run the Test Cases:
Open the imported test suite in Selenium IDE.
Click on the Play button to execute the test suite.
Monitor the execution to ensure that all test cases are successfully executed.

### Test Suite Details
The test suite consists of the following test cases:

home_page

search_page

corpora_page

glossary_page

about_page

admin_login

admin_account

admin_database


Each test case verifies specific functionalities and elements on the corresponding pages of the Flask application.

### Troubleshooting:
If you encounter any issues during the execution of the test suite, please ensure that:

The Selenium IDE extension is properly installed.

The browser is compatible with the Selenium IDE extension.

The application is running at the provided URL or on the local development server.

If the issue persists, please reach out to our support team for further assistance.

sudo apt-get -y remove ocrmypdf  # remove system ocrmypdf, if installed
sudo apt-get -y update
sudo apt-get -y install \
    ghostscript \
    icc-profiles-free \
    libxml2 \
    pngquant \
    python3-pip \
    tesseract-ocr \
    zlib1g